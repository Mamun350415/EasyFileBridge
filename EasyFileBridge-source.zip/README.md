# EasyFileBridge 1.1.0
Publisher: Mamun Or Rashid
Support: mamunahmed350415@gmail.com

English Android 8+ local file sharing with Send, Receive and Files, first-run agreement, QR pairing, TLS pinning and SHA-256 integrity verification.

Send: tap Send, approve the temporary hotspot and requested Android permissions, then choose files. The app displays a QR code containing the local pairing and hotspot details.
Receive: tap Receive, scan the sender QR, approve Allow and the Android Connect prompt, then select files to receive. Automatic receiver connection requires Android 10 or newer and compatible device support. Internet and mobile data are not required. Older devices can connect using Wi-Fi settings. Keep Location enabled if required by the phone. Existing Wi-Fi remains available as a fallback.

Keep pairing codes private; they include temporary hotspot credentials. Stop sharing releases the hotspot. Sessions expire after 30 minutes. Router isolation and manufacturer restrictions can prevent connection. Selecting files stages private cache copies and needs enough storage. Received files stay in app storage until exported; uninstalling removes them.

Build: Java 17, Gradle 8.9, Android SDK 35, AGP 8.7.3. Retain the existing signing secrets and key. Upload this archive as EasyFileBridge-source.zip at repository root, replacing the previous archive. The existing GitHub workflow unpacks it and builds the signed APK. Install the new APK on both devices.

Validation: Java syntax, XML, YAML and archive checks. No Android SDK build or real two-device test was available here. Validate the new connection flow before broad distribution.

Dependencies: AndroidX, ZXing core and ZXing Android Embedded, Apache 2.0. See their upstream license notices.
