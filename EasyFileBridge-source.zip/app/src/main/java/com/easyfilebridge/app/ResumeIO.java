package com.easyfilebridge.app;

import java.io.*;
import java.security.MessageDigest;

/** Checks resumed prefixes and positions streams without trusting skip() to skip fully. */
final class ResumeIO {
    interface Check { void run() throws IOException; }
    private ResumeIO() {}
    static String hash(File file, long count, Check check) throws Exception {
        if (count < 0 || count > file.length()) throw new IOException("Invalid resume position");
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[65536]; long remaining = count;
            while (remaining > 0) {
                check.run(); int n = in.read(buffer, 0, (int)Math.min(buffer.length, remaining));
                if (n < 0) throw new EOFException("Partial file changed");
                digest.update(buffer, 0, n); remaining -= n;
            }
        }
        return Protocol.hex(digest.digest());
    }
    static long acceptedOffset(File source, long requested, String prefix, Check check) throws Exception {
        if (requested < 0 || requested > source.length()) throw new IOException("Invalid resume position");
        return requested == 0 || Protocol.same(hash(source, requested, check), prefix) ? requested : 0;
    }
    static void validateAccepted(long requested, long accepted, long total) throws IOException {
        if (requested < 0 || requested > total || (accepted != 0 && accepted != requested)) throw new IOException("Invalid resume position");
    }
    static void skipFully(InputStream in, long count) throws IOException {
        if (count < 0) throw new IOException("Invalid resume position");
        while (count > 0) {
            long skipped = in.skip(count);
            if (skipped > 0) count -= skipped;
            else { if (in.read() < 0) throw new EOFException("Source file changed"); count--; }
        }
    }
}
