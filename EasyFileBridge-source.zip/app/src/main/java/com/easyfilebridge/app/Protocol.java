package com.easyfilebridge.app;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

public final class Protocol {
    public static final int MAX_JSON = 262144;
    public static final int MAX_FILES = 200;
    public static final long MAX_FILE_BYTES = 100L * 1024 * 1024 * 1024;
    private Protocol() {}
    public static String readText(DataInputStream in) throws IOException {
        int n = in.readInt();
        if (n < 0 || n > MAX_JSON) throw new IOException("Invalid message size");
        byte[] b = new byte[n]; in.readFully(b);
        return new String(b, StandardCharsets.UTF_8);
    }
    public static void writeText(DataOutputStream out, String value) throws IOException {
        byte[] b = value.getBytes(StandardCharsets.UTF_8);
        if (b.length > MAX_JSON) throw new IOException("Message too large");
        out.writeInt(b.length); out.write(b); out.flush();
    }
    public static String hex(byte[] bytes) {
        StringBuilder b = new StringBuilder();
        for (byte v : bytes) b.append(String.format(Locale.US, "%02x", v & 255));
        return b.toString();
    }
    public static boolean same(String a, String b) {
        return MessageDigest.isEqual(a.getBytes(StandardCharsets.UTF_8), b.getBytes(StandardCharsets.UTF_8));
    }
    public static String safeName(String name) {
        String clean = name.replaceAll("[\\\\/\\p{Cntrl}]", "_").trim();
        if (clean.isEmpty() || clean.equals(".") || clean.equals("..")) clean = "file";
        return clean.length() > 120 ? clean.substring(0, 120) : clean;
    }
    public static boolean localAddress(String host) {
        if (!host.matches("[0-9]{1,3}(\\.[0-9]{1,3}){3}")) return false;
        try {
            InetAddress ip = InetAddress.getByName(host);
            return ip instanceof Inet4Address && (ip.isSiteLocalAddress() || ip.isLoopbackAddress());
        } catch (Exception e) { return false; }
    }
    public static String amount(long n) {
        if (n < 1024) return n + " B";
        double v = n; String[] u = {"B", "KB", "MB", "GB", "TB"}; int i = 0;
        while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
        return String.format(Locale.US, "%.1f %s", v, u[i]);
    }
}
