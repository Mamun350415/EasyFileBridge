package com.easyfilebridge.app;

import android.content.Context;
import android.net.*;
import android.net.wifi.*;
import android.os.*;
import org.json.*;
import java.io.IOException;

/** Owns the local connection independently of a short-lived metadata service. */
final class NearbyLink {
    interface Result { void ready(); void failed(String message); }
    private static final Handler main = new Handler(Looper.getMainLooper());
    private static WifiManager.LocalOnlyHotspotReservation hotspot;
    private static ConnectivityManager manager;
    private static ConnectivityManager.NetworkCallback request;
    private static volatile Network network;
    private static String ssid = "", password = "";
    private static int generation;
    private static boolean pending;

    static JSONObject read(String code) throws Exception {
        if (code == null || !code.startsWith("EFB1:") || code.length() > 8192) throw new IOException("Scan an EasyFileBridge QR code");
        JSONObject j = new JSONObject(new String(android.util.Base64.decode(code.substring(5), android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP), java.nio.charset.StandardCharsets.UTF_8));
        if (j.getInt("v") != 1 || !j.getString("pin").matches("[a-f0-9]{64}") || !j.getString("token").matches("[a-f0-9-]{36}")) throw new IOException("Invalid pairing code");
        int port = j.getInt("port"); if (port < 1 || port > 65535) throw new IOException("Invalid port");
        JSONArray hosts = j.getJSONArray("hosts"); if (hosts.length() < 1 || hosts.length() > 8) throw new IOException("Invalid address");
        for (int i=0;i<hosts.length();i++) if (!Protocol.localAddress(hosts.getString(i))) throw new IOException("Invalid local address");
        JSONObject wifi = j.optJSONObject("wifi");
        if (wifi != null && (wifi.getString("ssid").isEmpty() || wifi.getString("ssid").length()>32 || wifi.getString("password").length()<8 || wifi.getString("password").length()>63)) throw new IOException("Invalid hotspot details");
        return j;
    }
    static synchronized JSONObject credentials() throws JSONException {
        return hotspot == null ? null : new JSONObject().put("ssid",ssid).put("password",password);
    }
    static void start(Context context, Result result) {
        close(); final int id = generation; pending = true;
        WifiManager wifi = (WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        try {
            wifi.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback() {
                @Override public void onStarted(WifiManager.LocalOnlyHotspotReservation reservation) {
                    if (id != generation || !pending) { reservation.close(); return; }
                    hotspot = reservation;
                    if (Build.VERSION.SDK_INT >= 30) {
                        SoftApConfiguration config = reservation.getSoftApConfiguration();
                        ssid = config.getSsid(); password = config.getPassphrase();
                    } else {
                        WifiConfiguration config = reservation.getWifiConfiguration();
                        ssid = config.SSID; password = config.preSharedKey;
                    }
                    if (ssid == null || password == null) { close(); result.failed("Hotspot details unavailable. Use existing Wi-Fi instead."); return; }
                    pending = false; result.ready();
                }
                @Override public void onFailed(int reason) {
                    if (id != generation || !pending) return;
                    close(); result.failed("Could not start hotspot. Turn off an existing hotspot and check Wi-Fi and Location settings, or use existing Wi-Fi.");
                }
                @Override public void onStopped() {
                    if (id != generation) return;
                    close(); context.stopService(new android.content.Intent(context, TransferService.class)); TransferService.status = "Hotspot stopped. Tap Send to start again.";
                }
            }, main);
            main.postDelayed(() -> { if (id == generation && pending) { close(); result.failed("Hotspot did not start. Please try again."); } }, 30000);
        } catch (Exception e) { close(); result.failed("Hotspot permission or device settings prevented connection. Use existing Wi-Fi or try again."); }
    }
    static void join(Context context, JSONObject info, Result result) {
        if (Build.VERSION.SDK_INT < 29) { result.failed("Automatic connection requires Android 10 or later."); return; }
        close(); final int id = generation; pending = true;
        try {
            JSONObject wifi = info.getJSONObject("wifi");
            WifiNetworkSpecifier specifier = new WifiNetworkSpecifier.Builder().setSsid(wifi.getString("ssid")).setWpa2Passphrase(wifi.getString("password")).build();
            NetworkRequest wanted = new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(specifier).build();
            manager = (ConnectivityManager)context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            request = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network connected) { main.post(() -> {
                    if (id != generation || !pending) return;
                    network = connected; pending = false; result.ready();
                }); }
                @Override public void onUnavailable() { main.post(() -> {
                    if (id != generation || !pending) return;
                    close(); result.failed("Connection cancelled or unavailable. Scan again and approve Connect.");
                }); }
                @Override public void onLost(Network lost) { main.post(() -> {
                    if (id != generation) return;
                    close(); context.stopService(new android.content.Intent(context, TransferService.class)); TransferService.status = "Connection lost. Scan the sender's QR code again.";
                }); }
            };
            manager.requestNetwork(wanted, request, 60000);
        } catch (Exception e) { close(); result.failed("Could not request Wi-Fi connection. Check permissions and turn Wi-Fi on."); }
    }
    static void bind(java.net.Socket socket) throws IOException { Network n=network; if(n!=null) n.bindSocket(socket); }
    static synchronized void close() {
        generation++; pending=false; network=null;
        if(request!=null && manager!=null) try { manager.unregisterNetworkCallback(request); } catch(Exception ignored) {}
        request=null; manager=null;
        if(hotspot!=null) hotspot.close(); hotspot=null; ssid=""; password="";
    }
}
