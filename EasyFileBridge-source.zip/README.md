# EasyFileBridge
Android 8+ English local file transfer app. Home: Send, Receive, Files. First-run agreement; QR pairing; TLS certificate pinning; SHA-256 integrity verification; multi-file selection; foreground progress and cancellation; private received files with export/open/delete.

Connect both phones to the same Wi-Fi or one phone hotspot. Sender selects files, receiver scans QR and chooses files. Sending stages a private cache copy, requiring enough free storage. Received files remain in app storage until exported; uninstall removes them. Sessions expire after 30 minutes. No discovery or Wi-Fi Direct automation. Router client isolation can prevent connection.

Build uses Java 17, Gradle 8.9, Android SDK 35 and AGP 8.7.3. Signing secrets are required. Uploaded source archive replaces previous app sources at build time. Do not upload private signing files. Back up the signing key permanently.

Validation: static configuration and archive checks only in this environment. Full Android build and two-device lifecycle/network checks must pass before distribution. Terms are a starter draft; publisher identity/contact and final policy review are required before public release.

Third-party dependencies: AndroidX (Apache 2.0), ZXing core (Apache 2.0), ZXing Android Embedded (Apache 2.0). See upstream projects for their license notices.
