package com.easyfilebridge.app;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.security.keystore.*;
import org.json.*;
import javax.net.ssl.*;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.concurrent.*;

public class TransferService extends Service {
    public static final String STOP = "com.easyfilebridge.STOP";
    public static volatile String status = "Ready to transfer";
    public static volatile String pairing = "";
    public static volatile int progress = 0;
    public static volatile boolean busy = false;
    public static volatile boolean sharing = false;
    public static volatile JSONArray offers = new JSONArray();
    public static volatile String incomingPair = "";
    public static final class Detail {
        final String phase, name;
        final long bytes, total, speed, seconds;
        final int index, count;
        Detail(String phase, String name, long bytes, long total, long speed, long seconds, int index, int count) {
            this.phase=phase; this.name=name; this.bytes=bytes; this.total=total; this.speed=speed; this.seconds=seconds; this.index=index; this.count=count;
        }
    }
    public static volatile Detail detail = new Detail("Ready", "", 0, 0, 0, -1, 0, 0);
    public static volatile String retryPair = "", lastError = "";
    public static volatile ArrayList<Integer> retryIds = new ArrayList<>();
    private int fileIndex, fileCount;
    private long rateOffset, rateStart, lastDetail;
    private static volatile TransferService instance;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Set<Socket> sockets = ConcurrentHashMap.newKeySet();
    private final List<File> staged = new ArrayList<>();
    private volatile boolean cancelled;
    private volatile SSLServerSocket listener;
    private File stageDir;
    private PowerManager.WakeLock wake;
    private long lastNotice;
    private String token;
    private boolean senderSession;
    private final ExecutorService clients = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(4));

    public static void cancel(Context context) {
        context.startService(new Intent(context, TransferService.class).setAction(STOP));
    }
    private void report(String message, int percent) {
        status = message; progress = Math.max(0, Math.min(100, percent));
        if (SystemClock.elapsedRealtime() - lastNotice > 700) {
            lastNotice = SystemClock.elapsedRealtime();
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7, notice());
        }
    }
    private Notification notice() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, TransferService.class).setAction(STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, "transfers").setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("EasyFileBridge").setContentText(status).setContentIntent(open)
            .setOngoing(true).addAction(new Notification.Action.Builder(null, "Stop", stop).build())
            .setProgress(100, progress, busy && progress == 0).build();
    }
    @Override public void onCreate() {
        super.onCreate(); instance = this;
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
            new NotificationChannel("transfers", "File transfers", NotificationManager.IMPORTANCE_LOW));
        wake = ((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "EasyFileBridge:transfer");
        stageDir = new File(getCacheDir(), "outgoing-" + UUID.randomUUID());
        stageDir.mkdirs();
        File received = new File(getFilesDir(), "received"); received.mkdirs();
        File parts = new File(getFilesDir(), "partials"); parts.mkdirs();
        File[] old = parts.listFiles();
        if (old != null) for (File f : old) if (System.currentTimeMillis() - f.lastModified() > 7L * 24 * 60 * 60 * 1000) f.delete();
    }
    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (STOP.equals(intent.getAction())) { stopNow("Transfer stopped"); return START_NOT_STICKY; }
        if (busy || sharing) return START_NOT_STICKY;
        cancelled = false; busy = true; status = "Connecting..."; progress = 0; lastError = "";
        detail = new Detail("Connecting", "", 0, 0, 0, -1, 0, 0);
        startForeground(7, notice());
        if (!wake.isHeld()) wake.acquire(60 * 60 * 1000L);
        String action = intent.getAction();
        worker.execute(() -> {
            try {
                if ("SEND".equals(action)) { senderSession = true; prepare(intent.getStringArrayListExtra("uris")); }
                else if ("LIST".equals(action)) loadOffer(intent.getStringExtra("pair"));
                else if ("RECEIVE".equals(action)) receive(intent.getStringExtra("pair"), intent.getIntegerArrayListExtra("ids"));
                else throw new IOException("Unknown operation");
            } catch (Exception e) {
                if (!cancelled) {
                    lastError = friendly(e); report("Could not complete transfer: " + lastError, progress);
                    Detail current = detail;
                    detail = new Detail("Interrupted", current.name, current.bytes, current.total, 0, -1, current.index, current.count);
                }
            } finally {
                busy = false;
                if (!sharing) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); }
            }
        });
        return START_NOT_STICKY;
    }
    private String friendly(Exception e) {
        if (e instanceof SocketTimeoutException) return "Connection timed out. Keep Send open, reconnect to the sender's Wi-Fi, then tap Retry.";
        if (e instanceof SecurityException) return "File access was denied. Choose the file again and allow access.";
        String m = e.getMessage(); return m == null ? "Please try again." : m;
    }
    private void check() throws IOException { if (cancelled || Thread.currentThread().isInterrupted()) throw new IOException("Cancelled"); }
    private void prepare(ArrayList<String> uris) throws Exception {
        retryPair = ""; retryIds = new ArrayList<>(); incomingPair = "";
        if (uris == null || uris.isEmpty() || uris.size() > Protocol.MAX_FILES) throw new IOException("Choose 1 to 200 files");
        JSONArray metadata = new JSONArray(); staged.clear();
        for (int i = 0; i < uris.size(); i++) {
            check(); Uri uri = Uri.parse(uris.get(i)); String name = "file";
            try (android.database.Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) name = c.getString(0);
            }
            name = Protocol.safeName(name == null ? "file" : name);
            File f = new File(stageDir, "item-" + i); MessageDigest digest = MessageDigest.getInstance("SHA-256");
            fileIndex = i + 1; fileCount = uris.size();
            detail = new Detail("Preparing", name, 0, 0, 0, -1, fileIndex, fileCount);
            long count = 0; report("Preparing " + (i + 1) + "/" + uris.size() + ": " + name, 0);
            try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(f)) {
                if (in == null) throw new IOException("Cannot read selected file");
                byte[] b = new byte[65536]; int n;
                while ((n = in.read(b)) != -1) {
                    check(); if (stageDir.getUsableSpace() < n + 16L * 1024 * 1024) throw new IOException("Not enough space to prepare files");
                    count += n; if (count > Protocol.MAX_FILE_BYTES) throw new IOException("File is too large");
                    out.write(b, 0, n); digest.update(b, 0, n);
                }
            }
            staged.add(f);
            metadata.put(new JSONObject().put("id", i).put("name", name).put("size", count).put("sha256", Protocol.hex(digest.digest())));
        }
        check(); offers = metadata; token = UUID.randomUUID().toString();
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        String alias = "efb-transport-v2";
        if (!ks.containsAlias(alias)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
                .setKeySize(2048).setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA384, KeyProperties.DIGEST_SHA512)
                .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1, KeyProperties.SIGNATURE_PADDING_RSA_PSS).build());
            generator.generateKeyPair();
        }
        final PrivateKey key = (PrivateKey)ks.getKey(alias, null);
        final X509Certificate certificate = (X509Certificate)ks.getCertificate(alias);
        X509ExtendedKeyManager manager = new X509ExtendedKeyManager() {
            public String[] getClientAliases(String t, java.security.Principal[] p) { return null; }
            public String chooseClientAlias(String[] t, java.security.Principal[] p, Socket s) { return null; }
            public String[] getServerAliases(String t, java.security.Principal[] p) { return "RSA".equals(t) ? new String[]{alias} : null; }
            public String chooseServerAlias(String t, java.security.Principal[] p, Socket s) { return "RSA".equals(t) ? alias : null; }
            public X509Certificate[] getCertificateChain(String a) { return new X509Certificate[]{certificate}; }
            public PrivateKey getPrivateKey(String a) { return key; }
        };
        SSLContext tls = SSLContext.getInstance("TLS"); tls.init(new KeyManager[]{manager}, null, new SecureRandom());
        listener = (SSLServerSocket)tls.getServerSocketFactory().createServerSocket(0);
        listener.setEnabledProtocols(new String[]{"TLSv1.2"});
        JSONArray hosts = new JSONArray(); Enumeration<NetworkInterface> networks = NetworkInterface.getNetworkInterfaces();
        while (networks.hasMoreElements()) {
            NetworkInterface network = networks.nextElement();
            if (!network.isUp() || network.isLoopback()) continue;
            Enumeration<InetAddress> ips = network.getInetAddresses();
            while (ips.hasMoreElements()) {
                InetAddress ip = ips.nextElement();
                String host = ip.getHostAddress();
                if (ip instanceof Inet4Address && ip.isSiteLocalAddress() && hosts.length() < 8) hosts.put(host);
            }
        }
        if (hosts.length() == 0) hosts.put("127.0.0.1");
        JSONObject info = new JSONObject().put("v", 1).put("hosts", hosts).put("port", listener.getLocalPort())
            .put("token", token).put("pin", Protocol.hex(MessageDigest.getInstance("SHA-256").digest(certificate.getEncoded())));
        JSONObject wifi = NearbyLink.credentials();
        if (wifi != null) info.put("wifi", wifi);
        pairing = "EFB1:" + android.util.Base64.encodeToString(info.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8), android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP);
        sharing = true; busy = false; detail = new Detail("Ready to share", "", 0, 0, 0, -1, 0, metadata.length()); report("Ready. Scan this QR code on the receiving phone.", 0);
        final SSLServerSocket local = listener;
        new Thread(() -> {
            long expires = SystemClock.elapsedRealtime() + 30 * 60 * 1000L;
            try {
                local.setSoTimeout(1000);
                while (!cancelled && !local.isClosed()) {
                    if (SystemClock.elapsedRealtime() > expires) { stopNow("Sharing expired. Select files to start again."); break; }
                    try {
                        Socket client = local.accept();
                        sockets.add(client);
                        try { clients.execute(() -> { try { serve(client, metadata); } finally { sockets.remove(client); try { client.close(); } catch (Exception ignored) {} } }); }
                        catch (RejectedExecutionException e) { sockets.remove(client); client.close(); }
                    } catch (SocketTimeoutException ignored) {}
                }
            } catch (Exception e) { if (!cancelled) stopNow("Sharing stopped: " + friendly(e)); }
        }, "EFB-listen").start();
    }
    private void serve(Socket client, JSONArray metadata) {
        JSONObject item = null;
        try {
            client.setSoTimeout(60000);
            DataInputStream in = new DataInputStream(client.getInputStream()); DataOutputStream out = new DataOutputStream(client.getOutputStream());
            JSONObject request = new JSONObject(Protocol.readText(in));
            if (!Protocol.same(token, request.optString("token"))) { Protocol.writeText(out, "{\"error\":\"Pairing rejected\"}"); return; }
            if ("LIST".equals(request.optString("op"))) { Protocol.writeText(out, new JSONObject().put("files", metadata).toString()); return; }
            if (!"GET".equals(request.optString("op"))) throw new IOException("Invalid request");
            int id = request.getInt("id"); if (id < 0 || id >= staged.size()) throw new IOException("Invalid file");
            item = metadata.getJSONObject(id); long total = item.getLong("size");
            long offset = request.optLong("offset", 0);
            if (offset < 0 || offset > total) throw new IOException("Invalid resume position");
            busy = true; fileIndex = id + 1; fileCount = metadata.length();
            detail = new Detail("Checking saved part", item.getString("name"), offset, total, 0, -1, fileIndex, fileCount);
            // An untrusted or corrupted prefix is restarted, never blindly appended.
            offset = ResumeIO.acceptedOffset(staged.get(id), offset, request.optString("prefix"), this::check);
            JSONObject header = new JSONObject(item.toString()).put("offset", offset);
            Protocol.writeText(out, header.toString());
            long sent = offset, started = SystemClock.elapsedRealtime(); rateOffset = offset; rateStart = started; lastDetail = 0;
            try (InputStream file = new FileInputStream(staged.get(id))) {
                ResumeIO.skipFully(file, offset);
                byte[] buffer = new byte[65536]; int n;
                while ((n = file.read(buffer)) != -1) {
                    check(); out.write(buffer, 0, n); sent += n; transferReport("Sending", item.getString("name"), sent, total, started);
                }
                out.flush();
            }
            client.setSoTimeout(300000); // Receiver may be hashing a large file before acknowledgement.
            JSONObject ack = new JSONObject(Protocol.readText(in));
            if (!"OK".equals(ack.optString("result"))) throw new IOException("Receiver did not verify file");
            detail = new Detail("Delivered & verified", item.getString("name"), total, total, 0, 0, fileIndex, fileCount);
            TransferHistory.add(this, "Sent", item.getString("name"), total, "Success");
            lastError = ""; report("Delivered and verified: " + item.getString("name"), 100);
        } catch (Exception e) {
            if (item != null) {
                TransferHistory.add(this, "Sent", item.optString("name"), item.optLong("size"), cancelled ? "Cancelled" : "Interrupted");
                if (!cancelled) { lastError = "Transfer interrupted. The receiver can reconnect and tap Retry to resume."; report(lastError, progress); }
            }
        } finally { if (item != null) busy = false; }
    }
    private JSONObject decode(String value) throws Exception {
        if (value == null || !value.startsWith("EFB1:") || value.length() > 8192) throw new IOException("Scan an EasyFileBridge QR code");
        JSONObject j = new JSONObject(new String(android.util.Base64.decode(value.substring(5), android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP), java.nio.charset.StandardCharsets.UTF_8));
        if (j.getInt("v") != 1 || !j.getString("pin").matches("[a-f0-9]{64}") || !j.getString("token").matches("[a-f0-9-]{36}")) throw new IOException("Invalid pairing code");
        int port = j.getInt("port"); if (port < 1 || port > 65535) throw new IOException("Invalid port");
        JSONArray hosts = j.getJSONArray("hosts"); if (hosts.length() < 1 || hosts.length() > 8) throw new IOException("Invalid address");
        for (int i = 0; i < hosts.length(); i++) if (!Protocol.localAddress(hosts.getString(i))) throw new IOException("Use a local Wi-Fi connection");
        return j;
    }
    private SSLSocket connect(JSONObject info) throws Exception {
        final String pin = info.getString("pin");
        X509TrustManager trust = new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            public void checkClientTrusted(X509Certificate[] c, String a) throws java.security.cert.CertificateException { throw new java.security.cert.CertificateException("Unsupported"); }
            public void checkServerTrusted(X509Certificate[] c, String a) throws java.security.cert.CertificateException {
                try {
                    if (c.length < 1 || !Protocol.same(pin, Protocol.hex(MessageDigest.getInstance("SHA-256").digest(c[0].getEncoded())))) throw new Exception("QR fingerprint mismatch");
                } catch (Exception e) { throw new java.security.cert.CertificateException("Sender identity did not match QR code", e); }
            }
        };
        SSLContext tls = SSLContext.getInstance("TLS"); tls.init(null, new TrustManager[]{trust}, new SecureRandom());
        Exception last = new IOException("Sender unavailable");
        SSLException secureError = null;
        for (android.net.Network selected : NearbyLink.wifiNetworks(this)) {
            for (String host : NearbyLink.hosts(this, selected, info)) {
                check(); Socket raw = selected.getSocketFactory().createSocket(); sockets.add(raw);
                SSLSocket secure = null;
                try {
                    raw.connect(new InetSocketAddress(host, info.getInt("port")), 4000);
                    raw.setSoTimeout(60000);
                    secure = (SSLSocket)tls.getSocketFactory().createSocket(raw, host, info.getInt("port"), true);
                    sockets.add(secure); secure.setSoTimeout(60000); secure.setEnabledProtocols(new String[]{"TLSv1.2"});
                    secure.startHandshake(); sockets.remove(raw); return secure;
                } catch (Exception e) {
                    if (e instanceof SSLException) secureError = (SSLException)e;
                    last = e;
                    if (secure != null) { sockets.remove(secure); try { secure.close(); } catch (Exception ignored) {} }
                    sockets.remove(raw); try { raw.close(); } catch (Exception ignored) {}
                }
            }
        }
        if (secureError != null) throw new IOException("Connected to sender, but secure verification failed. Update both apps and scan a fresh QR code. [TLS]", secureError);
        throw new IOException("Wi-Fi is connected, but sender did not respond. Keep Send open and scan a fresh QR. [" + last.getClass().getSimpleName() + "]", last);
    }
    private void loadOffer(String code) throws Exception {
        incomingPair = ""; offers = new JSONArray(); retryPair = ""; retryIds = new ArrayList<>(); JSONObject info = decode(code);
        try (SSLSocket s = connect(info)) {
            DataOutputStream out = new DataOutputStream(s.getOutputStream()); DataInputStream in = new DataInputStream(s.getInputStream());
            Protocol.writeText(out, new JSONObject().put("op", "LIST").put("token", info.getString("token")).toString());
            JSONArray files = new JSONObject(Protocol.readText(in)).getJSONArray("files"); validateFiles(files);
            offers = files; incomingPair = code; report("Choose files to receive", 0); sockets.remove(s);
        }
    }
    private void validateFiles(JSONArray files) throws Exception {
        if (files.length() < 1 || files.length() > Protocol.MAX_FILES) throw new IOException("Invalid file list");
        for (int i = 0; i < files.length(); i++) {
            JSONObject f = files.getJSONObject(i); long n = f.getLong("size");
            if (f.getInt("id") != i || n < 0 || n > Protocol.MAX_FILE_BYTES || !f.getString("sha256").matches("[a-f0-9]{64}") || f.getString("name").length() > 120) throw new IOException("Invalid file details");
        }
    }
    private void receive(String code, ArrayList<Integer> ids) throws Exception {
        if (ids == null || ids.isEmpty() || ids.size() > Protocol.MAX_FILES || !code.equals(incomingPair)) throw new IOException("Choose files first");
        JSONObject info = decode(code); JSONArray metadata = offers;
        LinkedHashSet<Integer> selected = new LinkedHashSet<>(ids);
        for (int id : selected) if (id < 0 || id >= metadata.length()) throw new IOException("Invalid selection");
        retryPair = code; retryIds = new ArrayList<>(selected); int done = 0; fileCount = selected.size();
        for (int id : selected) {
            check(); JSONObject expected = metadata.getJSONObject(id); fileIndex = done + 1;
            String name = Protocol.safeName(expected.getString("name")); long total = expected.getLong("size");
            Exception failure = null;
            for (int attempt = 0; attempt < 3; attempt++) {
                try { receiveFile(info, expected, name); failure = null; break; }
                catch (Exception e) {
                    failure = e; if (cancelled) break;
                    if (attempt == 2 || !recoverable(e)) break;
                    report("Connection interrupted. Retrying " + (attempt + 1) + "/2. Saved progress will be checked.", progress);
                    for (int wait = 0; wait < 8; wait++) { check(); Thread.sleep(100); }
                }
            }
            if (failure != null) {
                TransferHistory.add(this, "Received", name, total, cancelled ? "Cancelled" : "Interrupted");
                throw failure;
            }
            done++; ArrayList<Integer> remaining = new ArrayList<>(retryIds); remaining.remove(Integer.valueOf(id)); retryIds = remaining;
            TransferHistory.add(this, "Received", name, total, "Success");
        }
        retryPair = ""; retryIds = new ArrayList<>(); incomingPair = "";
        report("Received and verified " + done + " file(s). Open Files to view them.", 100);
    }
    private boolean recoverable(Exception error) {
        for (Throwable cause = error; cause != null; cause = cause.getCause()) if (cause instanceof SSLException || cause instanceof SecurityException) return false;
        String m = String.valueOf(error.getMessage()).toLowerCase(Locale.US);
        return error instanceof IOException && !m.contains("storage") && !m.contains("save") && !m.contains("changed") && !m.contains("invalid") && !m.contains("pairing") && !m.contains("verification") && !m.contains("local wi-fi");
    }
    private void receiveFile(JSONObject info, JSONObject expected, String name) throws Exception {
        long total = expected.getLong("size"); int id = expected.getInt("id");
        File dir = new File(getFilesDir(), "received"); dir.mkdirs();
        File parts = new File(getFilesDir(), "partials"); parts.mkdirs();
        File part = new File(parts, expected.getString("sha256") + "-" + total + ".part");
        if (part.length() > total && !part.delete()) throw new IOException("Cannot reset saved partial file");
        long offset = part.length(); part.setLastModified(System.currentTimeMillis());
        detail = new Detail(offset > 0 ? "Checking saved part" : "Connecting", name, offset, total, 0, -1, fileIndex, fileCount);
        String prefix = offset == 0 ? "" : ResumeIO.hash(part, offset, this::check);
        SSLSocket socket = connect(info);
        try (SSLSocket connection = socket) {
            DataOutputStream out = new DataOutputStream(connection.getOutputStream()); DataInputStream in = new DataInputStream(connection.getInputStream());
            Protocol.writeText(out, new JSONObject().put("op", "GET").put("token", info.getString("token")).put("id", id).put("offset", offset).put("prefix", prefix).toString());
            connection.setSoTimeout(300000); // Sender checks the saved prefix before returning a header.
            JSONObject header = new JSONObject(Protocol.readText(in));
            connection.setSoTimeout(60000);
            if (header.has("error")) throw new IOException(header.getString("error"));
            if (header.getLong("size") != total || !Protocol.same(header.getString("sha256"), expected.getString("sha256"))) throw new IOException("Sender file changed. Scan again.");
            long accepted = header.optLong("offset", 0); // Old app versions restart safely.
            ResumeIO.validateAccepted(offset, accepted, total);
            if (dir.getUsableSpace() < total - accepted + 16L * 1024 * 1024) throw new IOException("Not enough storage space. Free storage, then tap Retry.");
            long received = accepted, started = SystemClock.elapsedRealtime(); rateOffset = accepted; rateStart = started; lastDetail = 0;
            try (FileOutputStream file = new FileOutputStream(part, accepted > 0)) {
                byte[] buffer = new byte[65536];
                try {
                    transferReport("Receiving", name, received, total, started);
                    while (received < total) {
                        check(); int n = in.read(buffer, 0, (int)Math.min(buffer.length, total - received));
                        if (n < 0) throw new EOFException("Connection interrupted");
                        file.write(buffer, 0, n); received += n; transferReport("Receiving", name, received, total, started);
                    }
                } finally { file.getFD().sync(); }
            }
            detail = new Detail("Verifying file", name, total, total, 0, -1, fileIndex, fileCount);
            report("Verifying: " + name, 100);
            if (!Protocol.same(ResumeIO.hash(part, total, this::check), expected.getString("sha256"))) {
                part.delete(); throw new IOException("File verification failed. Tap Retry to download a fresh copy.");
            }
            File target = uniqueFile(dir, name); if (!part.renameTo(target)) throw new IOException("Cannot save received file. Free storage and tap Retry.");
            try { Protocol.writeText(out, "{\"result\":\"OK\"}"); } catch (IOException ignored) {}
            detail = new Detail("Received & verified", name, total, total, 0, 0, fileIndex, fileCount);
        } finally { sockets.remove(socket); }
    }
    private File uniqueFile(File dir, String name) {
        File f = new File(dir, name); int n = 1;
        while (f.exists()) f = new File(dir, (n++) + "-" + name);
        return f;
    }
    private void transferReport(String verb, String name, long n, long total, long start) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastDetail < 200 && n != total) return;
        lastDetail = now;
        long elapsed = Math.max(1, now - rateStart), transferred = Math.max(0, n - rateOffset);
        long speed = transferred * 1000 / elapsed;
        long seconds = speed == 0 ? -1 : Math.max(0, (total - n + speed - 1) / speed);
        detail = new Detail(verb, name, n, total, speed, seconds, fileIndex, fileCount);
        report(verb + ": " + name, total == 0 ? 100 : (int)(n * 100 / total));
    }
    private synchronized void stopNow(String message) {
        cancelled = true; sharing = false; busy = false; pairing = ""; incomingPair = ""; retryPair = ""; retryIds = new ArrayList<>(); status = message; progress = 0;
        detail = new Detail("Stopped", "", 0, 0, 0, -1, 0, 0);
        try { if (listener != null) listener.close(); } catch (Exception ignored) {}
        for (Socket s : sockets) try { s.close(); } catch (Exception ignored) {}
        sockets.clear(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
    }
    private void clearDir(File dir) { File[] files = dir.listFiles(); if (files != null) for (File f : files) f.delete(); }
    @Override public void onDestroy() {
        cancelled = true; sharing = false; busy = false; pairing = "";
        if (senderSession) NearbyLink.close();
        try { if (listener != null) listener.close(); } catch (Exception ignored) {}
        for (Socket s : sockets) try { s.close(); } catch (Exception ignored) {}
        worker.shutdownNow(); if (wake != null && wake.isHeld()) wake.release();
        clients.shutdownNow();
        new Thread(() -> { try { worker.awaitTermination(30, TimeUnit.SECONDS); clients.awaitTermination(30, TimeUnit.SECONDS); } catch (InterruptedException ignored) {} clearDir(stageDir); stageDir.delete(); }, "EFB-cleanup").start();
        instance = null; super.onDestroy();
    }
    @Override public void onTimeout(int startId, int fgsType) { stopNow("Transfer time limit reached. Please start again."); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
