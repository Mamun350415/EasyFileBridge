# EasyFileBridge 1.4.0
Publisher: Mamun Or Rashid
Support: mamunahmed350415@gmail.com

Android 8+ file sharing with an English Send / Receive / Files interface, light/dark/system themes, a compact home menu, nearby phone discovery and QR fallback.

## Transfer flow
Sender: tap Send, approve a temporary hotspot (or use an existing Wi-Fi connection), choose files and keep Send open. Use Show to nearby phones or display the QR code.
Receiver: use Find nearby phones and compare the verification code on both phones, or Scan QR code. Approve the Android hotspot connection and select files to receive.
Nearby discovery requires Google Play services, Bluetooth, Wi-Fi and runtime permissions. Device restrictions or router isolation can prevent a connection; QR and manual Wi-Fi remain alternatives. Automatic hotspot joining requires Android 10+ and compatible hardware. No mobile data or internet is needed for local file transfers.

## Version 1.4.0
- Separate file name, byte counts, transfer rate, estimated remaining time and per-file percentage. Preparing, checking saved parts and final verification are distinct phases.
- Interrupted downloads retain private partial files. Transient I/O errors get two automatic retry attempts, followed by a Retry / Resume button. A resumed prefix is checked against the sender before continuing; the entire received file is SHA-256 verified before being published.
- Resume requires both apps to support it. With an older sender, the receiver safely restarts. A new pairing can reuse the same content's saved part. Expired or stopped sender sessions must be paired again. Manual cancellation retains parts but clears the current retry selection.
- Partial files are private and excluded from Files. Parts unused for seven days are removed when a transfer service starts. Settings offers explicit cleanup. Clearing app data or uninstalling removes received and partial files.
- Files categories: All, Photos, Videos, Music, Documents, Other. Search works on received file names. Browse phone files opens the system picker, not an unrestricted storage scanner.
- Device-local history contains the last 100 file outcomes, direction, name, size and time. Clear history leaves actual files intact. Receiver success means the verified file was saved; sender success additionally requires the acknowledgement. No contents, pairing secrets or network addresses are recorded in history.
- Contextual storage, permission and connection guidance. No release checks are disabled.

## Privacy and security
Pairing codes include temporary hotspot credentials; share them only with the intended recipient. Files use certificate-pinned TLS and SHA-256 verification. Nearby discovery exchanges pairing details after both devices approve matching verification digits. Google Play services may collect Nearby usage/device diagnostics controlled by the device's Google Usage & diagnostics setting. No publisher analytics, ads, accounts or remote file server are included.

## Build and update
Java 17, Gradle 8.9, Android SDK 35, AGP 8.7.3. Retain the existing signing secrets/key and workflow. Upload EasyFileBridge-source.zip at the repository root, replacing the previous archive. The existing workflow unpacks the project and builds the signed APK. Update both phones.

## Validation
Java resume/integrity/protocol tests: 19 checks pass, including interrupted file reconstruction, corrupt-prefix restart, complete/empty files, invalid offsets, cancellation, skip fallback and UTF-8 framing. All Java source parses and XML/ZIP validation pass. Full Android compilation, release lint, UI rendering and two-device transport tests are not available in the authoring environment; the GitHub build and physical phones still need to verify those layers.

Reproduce pure Java tests with a JDK 17 from the project root:

```sh
mkdir -p test-classes
java com.sun.tools.javac.Main -d test-classes app/src/main/java/com/easyfilebridge/app/Protocol.java app/src/main/java/com/easyfilebridge/app/ResumeIO.java tests/ResumeTests.java
java -cp test-classes com.easyfilebridge.app.ResumeTests
```

## Dependencies
AndroidX and ZXing (Apache 2.0), Google Play services Nearby (Google Play services terms). Review upstream licenses/terms for distribution.
