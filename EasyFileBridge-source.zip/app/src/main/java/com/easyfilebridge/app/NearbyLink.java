package com.easyfilebridge.app;

import android.content.Context;
import android.net.*;
import android.net.wifi.*;
import android.os.*;
import org.json.*;
import java.io.IOException;
import java.net.*;
import java.util.*;

/** Owns the local connection independently of a short-lived metadata service. */
final class NearbyLink {
    interface Result { void ready(); void failed(String message); }
    private static final Handler main = new Handler(Looper.getMainLooper());
    private static volatile WifiManager.LocalOnlyHotspotReservation hotspot;
    private static ConnectivityManager manager;
    private static ConnectivityManager.NetworkCallback request;
    private static volatile Network network;
    private static volatile LinkProperties properties;
    private static volatile int security;
    private static volatile String ssid = "", password = "";
    private static int generation;
    private static boolean pending;

    static JSONObject read(String code) throws Exception {
        if (code == null || !code.startsWith("EFB1:") || code.length() > 8192) throw new IOException("Scan an EasyFileBridge QR code");
        JSONObject j = new JSONObject(new String(android.util.Base64.decode(code.substring(5), android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP), java.nio.charset.StandardCharsets.UTF_8));
        if (j.getInt("v") != 1 || !j.getString("pin").matches("[a-f0-9]{64}") || !j.getString("token").matches("[a-f0-9-]{36}")) throw new IOException("Invalid pairing code");
        int port = j.getInt("port"); if (port < 1 || port > 65535) throw new IOException("Invalid port");
        JSONArray hosts = j.getJSONArray("hosts"); if (hosts.length() < 1 || hosts.length() > 8) throw new IOException("Invalid address");
        for (int i=0;i<hosts.length();i++) if (!Protocol.localAddress(hosts.getString(i))) throw new IOException("Invalid local address");
        JSONObject wifi = j.optJSONObject("wifi");
        if (wifi != null && (wifi.getString("ssid").isEmpty() || wifi.getString("ssid").length()>32 || wifi.getString("password").length()<8 || wifi.getString("password").length()>63)) throw new IOException("Invalid hotspot details");
        return j;
    }
    static boolean hasHotspot() { return hotspot != null; }
    static synchronized JSONObject credentials() throws JSONException {
        return hotspot == null ? null : new JSONObject().put("ssid",ssid).put("password",password).put("security",security);
    }
    static void start(Context context, Result result) {
        close(); final int id = generation; pending = true;
        WifiManager wifi = (WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        try {
            wifi.startLocalOnlyHotspot(new WifiManager.LocalOnlyHotspotCallback() {
                @Override public void onStarted(WifiManager.LocalOnlyHotspotReservation reservation) {
                    if (id != generation || !pending) { reservation.close(); return; }
                    hotspot = reservation;
                    if (Build.VERSION.SDK_INT >= 30) {
                        SoftApConfiguration config = reservation.getSoftApConfiguration();
                        ssid = config.getSsid(); password = config.getPassphrase(); security = config.getSecurityType();
                    } else {
                        WifiConfiguration config = reservation.getWifiConfiguration();
                        ssid = unquote(config.SSID); password = unquote(config.preSharedKey); security = 0;
                    }
                    if (ssid == null || password == null) { close(); result.failed("Hotspot details unavailable. Use existing Wi-Fi instead."); return; }
                    pending = false; result.ready();
                }
                @Override public void onFailed(int reason) {
                    if (id != generation || !pending) return;
                    close(); result.failed("Could not start hotspot. Turn off an existing hotspot and check Wi-Fi and Location settings, or use existing Wi-Fi.");
                }
                @Override public void onStopped() {
                    if (id != generation) return;
                    close(); context.stopService(new android.content.Intent(context, TransferService.class)); TransferService.status = "Hotspot stopped. Tap Send to start again.";
                }
            }, main);
            main.postDelayed(() -> { if (id == generation && pending) { close(); result.failed("Hotspot did not start. Please try again."); } }, 30000);
        } catch (Exception e) { close(); result.failed("Hotspot permission or device settings prevented connection. Use existing Wi-Fi or try again."); }
    }
    static void join(Context context, JSONObject info, Result result) {
        if (Build.VERSION.SDK_INT < 29) { result.failed("Automatic connection requires Android 10 or later."); return; }
        close(); final int id = generation; pending = true;
        try {
            JSONObject wifi = info.getJSONObject("wifi");
            WifiNetworkSpecifier.Builder builder = new WifiNetworkSpecifier.Builder().setSsid(wifi.getString("ssid"));
            if (Build.VERSION.SDK_INT >= 30 && wifi.optInt("security", 0) == SoftApConfiguration.SECURITY_TYPE_WPA3_SAE) builder.setWpa3Passphrase(wifi.getString("password"));
            else builder.setWpa2Passphrase(wifi.getString("password"));
            WifiNetworkSpecifier specifier = builder.build();
            NetworkRequest wanted = new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(specifier).build();
            manager = (ConnectivityManager)context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            request = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network connected) { main.post(() -> {
                    if (id != generation || !pending) return;
                    network = connected; TransferService.status = "Connected. Waiting for Wi-Fi address...";
                }); }
                @Override public void onLinkPropertiesChanged(Network connected, LinkProperties links) {
                    final LinkProperties snapshot = links;
                    main.post(() -> {
                        if (id != generation) return;
                        network = connected; properties = snapshot;
                        if (pending && hasLocalAddress(snapshot)) {
                            pending = false; TransferService.status = "Wi-Fi ready. Contacting sender..."; result.ready();
                        }
                    });
                }
                @Override public void onUnavailable() { main.post(() -> {
                    if (id != generation || !pending) return;
                    close(); result.failed("Connection cancelled or unavailable. Scan again and approve Connect.");
                }); }
                @Override public void onLost(Network lost) { main.post(() -> {
                    if (id != generation) return;
                    boolean waiting = pending;
                    close(); context.stopService(new android.content.Intent(context, TransferService.class)); TransferService.status = "Connection lost. Scan the sender's QR code again.";
                    if (waiting) result.failed(TransferService.status);
                }); }
            };
            manager.requestNetwork(wanted, request, 60000);
            main.postDelayed(() -> {
                if (id == generation && pending) {
                    close(); result.failed("No usable hotspot connection. Keep the sender's Send screen open, turn on Wi-Fi and Location, then scan again. You can also connect using Wi-Fi settings.");
                }
            }, 65000);
        } catch (Exception e) { close(); result.failed("Could not request Wi-Fi connection. Check permissions and turn Wi-Fi on."); }
    }
    private static String unquote(String value) {
        return value != null && value.length() > 1 && value.startsWith("\"") && value.endsWith("\"") ? value.substring(1, value.length()-1) : value;
    }
    private static boolean hasLocalAddress(LinkProperties links) {
        for (LinkAddress address : links.getLinkAddresses())
            if (address.getAddress() instanceof Inet4Address && address.getAddress().isSiteLocalAddress()) return true;
        return false;
    }
    static List<Network> wifiNetworks(Context context) throws IOException {
        Network selected = network;
        if (selected != null) return Collections.singletonList(selected);
        List<Network> found = new ArrayList<>();
        ConnectivityManager cm = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        for (Network candidate : cm.getAllNetworks()) {
            NetworkCapabilities caps = cm.getNetworkCapabilities(candidate);
            LinkProperties links = cm.getLinkProperties(candidate);
            if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && links != null && hasLocalAddress(links)) found.add(candidate);
        }
        if (found.isEmpty()) throw new IOException("No local Wi-Fi connection. Approve Connect or join the sender's hotspot in Wi-Fi settings, then scan again.");
        return found;
    }
    static List<String> hosts(Context context, Network selected, JSONObject info) throws JSONException {
        LinkedHashSet<String> result = new LinkedHashSet<>();
        if (info.has("wifi")) {
            LinkProperties links = selected.equals(network) ? properties : null;
            if (links == null) links = ((ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE)).getLinkProperties(selected);
            if (links != null) for (RouteInfo route : links.getRoutes()) {
                InetAddress gateway = route.getGateway();
                if (gateway instanceof Inet4Address && gateway.isSiteLocalAddress()) result.add(gateway.getHostAddress());
            }
        }
        JSONArray addresses = info.getJSONArray("hosts");
        for (int i=0;i<addresses.length();i++) result.add(addresses.getString(i));
        return new ArrayList<>(result);
    }
    static synchronized void close() {
        generation++; pending=false; network=null; properties=null;
        if(request!=null && manager!=null) try { manager.unregisterNetworkCallback(request); } catch(Exception ignored) {}
        request=null; manager=null;
        if(hotspot!=null) hotspot.close(); hotspot=null; ssid=""; password="";
    }
}
