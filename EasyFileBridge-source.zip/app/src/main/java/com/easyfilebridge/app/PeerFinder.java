package com.easyfilebridge.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.*;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

/** Authenticated exchange of the existing TLS pairing code; never sends file data. */
final class PeerFinder {
    interface Events {
        void message(String message);
        void devices(Map<String, String> devices);
        void paired(String code);
    }
    private final Activity activity;
    private final ConnectionsClient client;
    private final Events events;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, String> devices = new LinkedHashMap<>();
    private final String outgoing;
    private boolean closed, connecting, received;
    private String endpoint = "";
    private AlertDialog approval;
    private static final String SERVICE = "com.easyfilebridge.app.pair.v1";
    PeerFinder(Activity activity, String outgoing, Events events) {
        this.activity = activity; this.outgoing = outgoing; this.events = events;
        client = Nearby.getConnectionsClient(activity);
    }
    void start() {
        if (outgoing.isEmpty()) {
            client.startDiscovery(SERVICE, new EndpointDiscoveryCallback() {
                @Override public void onEndpointFound(String id, DiscoveredEndpointInfo info) {
                    if (closed) return;
                    if (devices.size() >= 20 && !devices.containsKey(id)) return;
                    devices.put(id, info.getEndpointName()); events.devices(new LinkedHashMap<>(devices));
                }
                @Override public void onEndpointLost(String id) {
                    if (closed) return;
                    devices.remove(id); events.devices(new LinkedHashMap<>(devices));
                }
            }, new DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
                .addOnSuccessListener(v -> { if (!closed) events.message("Searching for nearby senders. You can scan a QR code instead."); })
                .addOnFailureListener(e -> fail("Could not search nearby phones. Use Scan QR code instead."));
        } else {
            client.startAdvertising(Build.MODEL, SERVICE, lifecycle,
                new AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build())
                .addOnSuccessListener(v -> { if (!closed) events.message("Visible as " + Build.MODEL + ". Keep Send open, or let the receiver scan your QR code."); })
                .addOnFailureListener(e -> fail("Nearby visibility is unavailable. The receiver can still scan your QR code."));
        }
        handler.postDelayed(() -> { if (!closed) fail("Nearby search ended. Try again or use the QR code."); }, 90000);
    }
    void choose(String id) {
        if (closed || connecting || !devices.containsKey(id)) return;
        connecting = true; endpoint = id; client.stopDiscovery();
        events.message("Connecting. Compare the code on both phones.");
        client.requestConnection(Build.MODEL, id, lifecycle)
            .addOnFailureListener(e -> fail("Could not connect to that phone. Try again or scan its QR code."));
    }
    private final ConnectionLifecycleCallback lifecycle = new ConnectionLifecycleCallback() {
        @Override public void onConnectionInitiated(String id, ConnectionInfo info) {
            if (closed || (!endpoint.isEmpty() && !endpoint.equals(id)) || activity.isFinishing() || activity.isDestroyed()) {
                client.rejectConnection(id); return;
            }
            endpoint = id; connecting = true;
            approval = new AlertDialog.Builder(activity).setTitle("Connect to " + info.getEndpointName() + "?")
                .setMessage("Compare this code on both phones:\n\n" + info.getAuthenticationDigits() + "\n\nAccept only if the codes match.")
                .setPositiveButton("Accept", (d,w) -> {
                    if (!closed) client.acceptConnection(id, payloads).addOnFailureListener(e -> fail("Connection approval failed. Use the QR code."));
                })
                .setNegativeButton("Reject", (d,w) -> { client.rejectConnection(id); fail("Connection rejected. Try again or use the QR code."); })
                .setOnCancelListener(d -> { client.rejectConnection(id); fail("Connection cancelled. Use the QR code or try again."); }).show();
        }
        @Override public void onConnectionResult(String id, ConnectionResolution result) {
            if (closed) return;
            if (!result.getStatus().isSuccess()) { fail("Connection was not accepted. Try again or use the QR code."); return; }
            client.stopAdvertising(); client.stopDiscovery();
            if (!outgoing.isEmpty()) {
                if (!TransferService.sharing || !outgoing.equals(TransferService.pairing)) { fail("Sharing has stopped. Choose files again."); return; }
                client.sendPayload(id, Payload.fromBytes(outgoing.getBytes(StandardCharsets.UTF_8)))
                    .addOnFailureListener(e -> fail("Could not send connection details. Use the QR code."));
            }
            events.message("Approved. Exchanging secure connection details...");
        }
        @Override public void onDisconnected(String id) {
            if (!closed) fail("Nearby connection closed. Try again or use the QR code.");
        }
    };
    private final PayloadCallback payloads = new PayloadCallback() {
        @Override public void onPayloadReceived(String id, Payload payload) {
            if (closed || !id.equals(endpoint) || payload.getType() != Payload.Type.BYTES) return;
            byte[] bytes = payload.asBytes();
            if (bytes == null || bytes.length > 16000) { fail("Invalid connection details. Use the QR code."); return; }
            String value = new String(bytes, StandardCharsets.UTF_8);
            if (outgoing.isEmpty()) {
                if (received) return;
                try { NearbyLink.read(value); } catch (Exception e) { fail("Invalid connection details. Scan the sender's QR code."); return; }
                received = true;
                client.sendPayload(id, Payload.fromBytes("EFB-ACK".getBytes(StandardCharsets.UTF_8)))
                    .addOnSuccessListener(v -> {
                        if (closed) return;
                        // Allow the acknowledgement to reach the sender before releasing Nearby radios.
                        handler.postDelayed(() -> { if (!closed) { close(); events.paired(value); } }, 700);
                    }).addOnFailureListener(e -> fail("Could not finish pairing. Scan the QR code."));
            } else if ("EFB-ACK".equals(value)) {
                close(); events.message("Phone paired. Approve the hotspot connection on the receiver.");
            }
        }
        @Override public void onPayloadTransferUpdate(String id, PayloadTransferUpdate update) {
            if (!closed && update.getStatus() == PayloadTransferUpdate.Status.FAILURE) fail("Pairing exchange failed. Use the QR code.");
        }
    };
    private void fail(String message) { if (closed) return; close(); events.message(message); }
    void close() {
        if (closed) return; closed = true; handler.removeCallbacksAndMessages(null);
        if (approval != null) { approval.setOnCancelListener(null); approval.dismiss(); approval = null; }
        client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints(); devices.clear();
    }
}
