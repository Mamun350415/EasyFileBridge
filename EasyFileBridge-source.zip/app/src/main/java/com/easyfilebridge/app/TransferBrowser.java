package com.easyfilebridge.app;

import android.Manifest;
import android.content.*;
import android.content.pm.*;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.*;
import java.util.concurrent.*;

/** Native selection browser. Permission failures always retain system-picker fallback. */
final class TransferBrowser extends LinearLayout {
    interface Actions { void send(ArrayList<String> uris); void receive(); void picker(String type); void permissions(String[] values, Runnable done); void menu(); void history(); }
    static final class Item {
        Uri uri; String name; long size, duration; android.graphics.drawable.Drawable icon; boolean split;
        Item(Uri u,String n,long s) { uri=u; name=n; size=s; }
    }
    private final Context context;
    private final Actions actions;
    private final int ink, muted, surface, card, green=Color.rgb(0,145,105);
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newFixedThreadPool(2);
    private final LinkedHashMap<String,Item> selected=new LinkedHashMap<>();
    private final ArrayList<Item> items=new ArrayList<>();
    private LinearLayout content,tabs;
    private TextView count;
    private Button send;
    private String category="Photos", query="";
    private int generation, limit=60;
    private boolean closed;
    TransferBrowser(Context c,Actions a,int i,int m,int s,int panel) {
        super(c); context=c; actions=a; ink=i; muted=m; surface=s; card=panel; setOrientation(VERTICAL); setBackgroundColor(surface);
        LinearLayout header=new LinearLayout(c); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(12),dp(8),dp(16),dp(8)); header.setBackgroundColor(green);
        Button menu=button("☰",()->actions.menu()); menu.setTextColor(Color.WHITE); header.addView(menu,new LayoutParams(dp(56),dp(48)));
        TextView title=label("EasyFileBridge",22,Color.WHITE); header.addView(title,new LayoutParams(0,-2,1)); addView(header);
        HorizontalScrollView bar=new HorizontalScrollView(c); bar.setHorizontalScrollBarEnabled(false); bar.setBackgroundColor(green); tabs=new LinearLayout(c); bar.addView(tabs); addView(bar,new LayoutParams(-1,dp(54)));
        for(String tab:new String[]{"History","Apps","Photos","Videos","Music","Files"}) {
            Button b=button(tab,()->{ if("History".equals(tab)) { actions.history(); return; } category=tab; limit=60; load(); });
            b.setTextColor(Color.WHITE); tabs.addView(b,new LayoutParams(dp(92),-1));
        }
        EditText search=new EditText(c); search.setSingleLine(true); search.setHint("Search files"); search.setTextColor(ink); search.setHintTextColor(muted); search.setTextSize(15); search.setPadding(dp(16),dp(8),dp(16),dp(8)); addView(search,new LayoutParams(-1,dp(52)));
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int co,int af){} public void afterTextChanged(android.text.Editable e){} public void onTextChanged(CharSequence s,int st,int before,int co){query=s.toString(); limit=60; render();}});
        count=label("",13,muted); count.setPadding(dp(16),dp(8),dp(16),dp(8)); addView(count);
        ScrollView scroll=new ScrollView(c); content=new LinearLayout(c); content.setOrientation(VERTICAL); content.setPadding(dp(8),0,dp(8),dp(16)); scroll.addView(content); addView(scroll,new LayoutParams(-1,0,1));
        LinearLayout footer=new LinearLayout(c); footer.setPadding(dp(16),dp(12),dp(16),dp(12)); footer.setBackgroundColor(surface);
        send=button("SEND",()->{if(selected.isEmpty()) actions.picker("*/*"); else {ArrayList<String> uris=new ArrayList<>(); for(Item item:selected.values()) uris.add(item.uri.toString()); actions.send(uris);}});
        Button receive=button("RECEIVE",()->actions.receive());
        for(Button b:new Button[]{send,receive}) { b.setTextColor(Color.WHITE); b.setBackground(round(green,28)); LayoutParams p=new LayoutParams(0,dp(56),1); p.setMargins(dp(4),0,dp(4),0);footer.addView(b,p); }
        addView(footer); load();
    }
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView label(String s,int size,int color){TextView t=new TextView(context);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private Button button(String name,Runnable task){Button b=new Button(context);b.setText(name);b.setAllCaps(false);b.setTextSize(15);b.setBackgroundColor(Color.TRANSPARENT);b.setOnClickListener(v->task.run());return b;}
    private String mime(){return "Photos".equals(category)?"image/*":"Videos".equals(category)?"video/*":"Music".equals(category)?"audio/*":"*/*";}
    private void load(){
        final int id=++generation; final String type=category;
        for(int i=0;i<tabs.getChildCount();i++) {Button b=(Button)tabs.getChildAt(i);b.setTypeface(null,b.getText().toString().equals(type)?Typeface.BOLD:Typeface.NORMAL);}
        items.clear();content.removeAllViews();count.setText(type+" · Loading...");
        if("Files".equals(type)){ files(); return; }
        if(!"Apps".equals(type)) {
            String permission=Build.VERSION.SDK_INT>=33?("Photos".equals(type)?Manifest.permission.READ_MEDIA_IMAGES:"Videos".equals(type)?Manifest.permission.READ_MEDIA_VIDEO:Manifest.permission.READ_MEDIA_AUDIO):Manifest.permission.READ_EXTERNAL_STORAGE;
            if(context.checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED){
                count.setText(type+" · Allow access or select files with Android's picker");
                content.addView(button("Allow "+type+" access",()->actions.permissions(new String[]{permission},()->{if(!closed && type.equals(category))load();})));
                content.addView(button("Choose "+type+" files",()->actions.picker(mime())));return;
            }
        }
        worker.execute(()->{
            ArrayList<Item> found=new ArrayList<>();String error="";
            try {
                if("Apps".equals(type)) {
                    LinkedHashMap<String,ApplicationInfo> apps=new LinkedHashMap<>();
                    for(ResolveInfo result:context.getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0))apps.put(result.activityInfo.packageName,result.activityInfo.applicationInfo);
                    for(ApplicationInfo app:apps.values()) {File file=new File(app.sourceDir);Item item=new Item(Uri.fromFile(file).buildUpon().fragment(app.packageName+".apk").build(),context.getPackageManager().getApplicationLabel(app).toString(),file.length());item.icon=context.getPackageManager().getApplicationIcon(app);item.split=app.splitSourceDirs!=null&&app.splitSourceDirs.length>0;found.add(item);}
                    found.sort((x,y)->x.name.compareToIgnoreCase(y.name));
                } else {
                    Uri collection="Photos".equals(type)?MediaStore.Images.Media.EXTERNAL_CONTENT_URI:"Videos".equals(type)?MediaStore.Video.Media.EXTERNAL_CONTENT_URI:MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                    String[] projection="Photos".equals(type)?new String[]{"_id","_display_name","_size"}:new String[]{"_id","_display_name","_size","duration"};
                    try(Cursor cursor=context.getContentResolver().query(collection,projection,null,null,"date_added DESC")) {
                        if(cursor!=null)while(cursor.moveToNext()){Item item=new Item(ContentUris.withAppendedId(collection,cursor.getLong(0)),cursor.getString(1),cursor.getLong(2));if(projection.length>3)item.duration=cursor.getLong(3);found.add(item);}
                    }
                }
            }catch(Exception e){error="Cannot read these files. Use Choose files instead.";}
            final String message=error;
            main.post(()->{if(closed||id!=generation)return;items.addAll(found);render();if(!message.isEmpty())count.setText(message);});
        });
    }
    private void files(){
        android.os.StatFs stat=new android.os.StatFs(context.getFilesDir().getAbsolutePath());
        TextView storage=label("Phone storage\n"+Protocol.amount(stat.getAvailableBytes())+" available / "+Protocol.amount(stat.getTotalBytes()),18,ink);storage.setPadding(dp(16),dp(20),dp(16),dp(20));storage.setBackground(round(card,18));content.addView(storage);
        for(String name:new String[]{"Documents","Ebooks","APKs","Archives","All files"})content.addView(button(name+"  ›",()->actions.picker("Documents".equals(name)?"application/*":"Ebooks".equals(name)?"application/epub+zip":"APKs".equals(name)?"application/vnd.android.package-archive":"Archives".equals(name)?"application/zip":"*/*")));
        count.setText("Files · Choose from phone storage");
    }
    private void render(){
        if(closed||"Files".equals(category))return;
        content.removeAllViews(); boolean grid=!"Music".equals(category);LinearLayout row=null;int columns=Math.max(2,Math.min("Apps".equals(category)?4:3,getResources().getConfiguration().screenWidthDp/100));int matched=0;
        for(Item item:items){if(item.name==null||!item.name.toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT)))continue;matched++;if(matched>limit)continue;
            if(grid&&(matched-1)%columns==0){row=new LinearLayout(context);content.addView(row,new LayoutParams(-1,-2));}
            LinearLayout cell=new LinearLayout(context);cell.setOrientation(VERTICAL);cell.setPadding(dp(4),dp(6),dp(4),dp(8));cell.setBackground(round(selected.containsKey(item.uri.toString())?green:surface,12));
            ImageView image=new ImageView(context);image.setScaleType(ImageView.ScaleType.CENTER_CROP);image.setContentDescription(item.name);image.setImageResource("Apps".equals(category)?android.R.drawable.sym_def_app_icon:android.R.drawable.ic_menu_gallery);
            if(item.icon!=null)image.setImageDrawable(item.icon);
            cell.addView(image,new LayoutParams(-1,dp("Apps".equals(category)?60:grid?112:40)));
            TextView name=label((selected.containsKey(item.uri.toString())?"✓ ":"○ ")+item.name,grid?12:16,ink);name.setMaxLines(2);name.setEllipsize(android.text.TextUtils.TruncateAt.END);cell.addView(name);
            cell.addView(label(Protocol.amount(item.size)+(item.duration>0?" · "+(item.duration/60000)+":"+String.format(Locale.US,"%02d",item.duration/1000%60):"")+(item.split?" · Split APK":""),11,muted));
            if(grid)row.addView(cell,new LayoutParams(0,-2,1));else content.addView(cell,new LayoutParams(-1,-2));
            cell.setOnClickListener(v->{String key=item.uri.toString();if(item.split){Toast.makeText(context,"This app requires multiple APK parts. Choose a complete installer instead.",Toast.LENGTH_LONG).show();return;}if(selected.containsKey(key))selected.remove(key);else if(selected.size()<200)selected.put(key,item);else Toast.makeText(context,"Select up to 200 files",Toast.LENGTH_SHORT).show();render();});
            if(item.icon==null&&grid&&Build.VERSION.SDK_INT>=29){final int id=generation;worker.execute(()->{Bitmap thumb=null;try{thumb=context.getContentResolver().loadThumbnail(item.uri,new android.util.Size(160,160),null);}catch(Exception ignored){}final Bitmap result=thumb;main.post(()->{if(result!=null){if(!closed&&id==generation&&image.isAttachedToWindow())image.setImageBitmap(result);else result.recycle();}});});}
        }
        if(grid&&row!=null)while(row.getChildCount()<columns)row.addView(new View(context),new LayoutParams(0,1,1));
        count.setText(category+" · "+matched+" files · "+selected.size()+" selected");send.setText(selected.isEmpty()?"SEND":"SEND ("+selected.size()+")");
        if(matched>limit)content.addView(button("Load more",()->{limit+=60;render();}));
        content.addView(button("Choose files with Android picker",()->actions.picker(mime())));
    }
    void close(){closed=true;generation++;worker.shutdown();}
}
