package com.easyfilebridge.app;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.security.keystore.*;
import org.json.*;
import javax.net.ssl.*;
import java.io.*;
import java.net.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.concurrent.*;

public class TransferService extends Service {
    public static final String STOP = "com.easyfilebridge.STOP";
    public static volatile String status = "Ready to transfer";
    public static volatile String pairing = "";
    public static volatile int progress = 0;
    public static volatile boolean busy = false;
    public static volatile boolean sharing = false;
    public static volatile JSONArray offers = new JSONArray();
    public static volatile String incomingPair = "";
    private static volatile TransferService instance;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Set<Socket> sockets = ConcurrentHashMap.newKeySet();
    private final List<File> staged = new ArrayList<>();
    private volatile boolean cancelled;
    private volatile SSLServerSocket listener;
    private File stageDir;
    private PowerManager.WakeLock wake;
    private long lastNotice;
    private String token;
    private boolean senderSession;
    private final ExecutorService clients = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<>(4));

    public static void cancel(Context context) {
        context.startService(new Intent(context, TransferService.class).setAction(STOP));
    }
    private void report(String message, int percent) {
        status = message; progress = Math.max(0, Math.min(100, percent));
        if (SystemClock.elapsedRealtime() - lastNotice > 700) {
            lastNotice = SystemClock.elapsedRealtime();
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7, notice());
        }
    }
    private Notification notice() {
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, TransferService.class).setAction(STOP), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, "transfers").setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("EasyFileBridge").setContentText(status).setContentIntent(open)
            .setOngoing(true).addAction(new Notification.Action.Builder(null, "Stop", stop).build())
            .setProgress(100, progress, busy && progress == 0).build();
    }
    @Override public void onCreate() {
        super.onCreate(); instance = this;
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(
            new NotificationChannel("transfers", "File transfers", NotificationManager.IMPORTANCE_LOW));
        wake = ((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "EasyFileBridge:transfer");
        stageDir = new File(getCacheDir(), "outgoing-" + UUID.randomUUID());
        stageDir.mkdirs();
        File received = new File(getFilesDir(), "received"); received.mkdirs();
        File[] partial = received.listFiles((dir, name) -> name.endsWith(".part"));
        if (partial != null) for (File f : partial) f.delete();
    }
    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (STOP.equals(intent.getAction())) { stopNow("Transfer stopped"); return START_NOT_STICKY; }
        if (busy || sharing) return START_NOT_STICKY;
        cancelled = false; busy = true; status = "Connecting..."; progress = 0;
        startForeground(7, notice());
        if (!wake.isHeld()) wake.acquire(60 * 60 * 1000L);
        String action = intent.getAction();
        worker.execute(() -> {
            try {
                if ("SEND".equals(action)) { senderSession = true; prepare(intent.getStringArrayListExtra("uris")); }
                else if ("LIST".equals(action)) loadOffer(intent.getStringExtra("pair"));
                else if ("RECEIVE".equals(action)) receive(intent.getStringExtra("pair"), intent.getIntegerArrayListExtra("ids"));
                else throw new IOException("Unknown operation");
            } catch (Exception e) {
                if (!cancelled) report("Could not complete transfer: " + friendly(e), 0);
            } finally {
                busy = false;
                if (!sharing) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); }
            }
        });
        return START_NOT_STICKY;
    }
    private String friendly(Exception e) {
        if (e instanceof SocketTimeoutException) return "Connection timed out. Check Wi-Fi or hotspot.";
        String m = e.getMessage(); return m == null ? "Please try again." : m;
    }
    private void check() throws IOException { if (cancelled || Thread.currentThread().isInterrupted()) throw new IOException("Cancelled"); }
    private void prepare(ArrayList<String> uris) throws Exception {
        if (uris == null || uris.isEmpty() || uris.size() > Protocol.MAX_FILES) throw new IOException("Choose 1 to 200 files");
        JSONArray metadata = new JSONArray(); staged.clear();
        for (int i = 0; i < uris.size(); i++) {
            check(); Uri uri = Uri.parse(uris.get(i)); String name = "file";
            try (android.database.Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) name = c.getString(0);
            }
            name = Protocol.safeName(name == null ? "file" : name);
            File f = new File(stageDir, "item-" + i); MessageDigest digest = MessageDigest.getInstance("SHA-256");
            long count = 0; report("Preparing " + (i + 1) + "/" + uris.size() + ": " + name, 0);
            try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(f)) {
                if (in == null) throw new IOException("Cannot read selected file");
                byte[] b = new byte[65536]; int n;
                while ((n = in.read(b)) != -1) {
                    check(); if (stageDir.getUsableSpace() < n + 16L * 1024 * 1024) throw new IOException("Not enough space to prepare files");
                    count += n; if (count > Protocol.MAX_FILE_BYTES) throw new IOException("File is too large");
                    out.write(b, 0, n); digest.update(b, 0, n);
                }
            }
            staged.add(f);
            metadata.put(new JSONObject().put("id", i).put("name", name).put("size", count).put("sha256", Protocol.hex(digest.digest())));
        }
        check(); offers = metadata; token = UUID.randomUUID().toString();
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        String alias = "efb-transport";
        if (!ks.containsAlias(alias)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore");
            generator.initialize(new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
                .setKeySize(2048).setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
                .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1).build());
            generator.generateKeyPair();
        }
        final PrivateKey key = (PrivateKey)ks.getKey(alias, null);
        final X509Certificate certificate = (X509Certificate)ks.getCertificate(alias);
        X509ExtendedKeyManager manager = new X509ExtendedKeyManager() {
            public String[] getClientAliases(String t, java.security.Principal[] p) { return null; }
            public String chooseClientAlias(String[] t, java.security.Principal[] p, Socket s) { return null; }
            public String[] getServerAliases(String t, java.security.Principal[] p) { return "RSA".equals(t) ? new String[]{alias} : null; }
            public String chooseServerAlias(String t, java.security.Principal[] p, Socket s) { return "RSA".equals(t) ? alias : null; }
            public X509Certificate[] getCertificateChain(String a) { return new X509Certificate[]{certificate}; }
            public PrivateKey getPrivateKey(String a) { return key; }
        };
        SSLContext tls = SSLContext.getInstance("TLS"); tls.init(new KeyManager[]{manager}, null, new SecureRandom());
        listener = (SSLServerSocket)tls.getServerSocketFactory().createServerSocket(0);
        listener.setEnabledProtocols(new String[]{"TLSv1.2"});
        JSONArray hosts = new JSONArray(); Enumeration<NetworkInterface> networks = NetworkInterface.getNetworkInterfaces();
        while (networks.hasMoreElements()) {
            NetworkInterface network = networks.nextElement();
            if (!network.isUp() || network.isLoopback()) continue;
            Enumeration<InetAddress> ips = network.getInetAddresses();
            while (ips.hasMoreElements()) {
                InetAddress ip = ips.nextElement();
                String host = ip.getHostAddress();
                if (ip instanceof Inet4Address && ip.isSiteLocalAddress() && hosts.length() < 8) hosts.put(host);
            }
        }
        if (hosts.length() == 0) hosts.put("127.0.0.1");
        JSONObject info = new JSONObject().put("v", 1).put("hosts", hosts).put("port", listener.getLocalPort())
            .put("token", token).put("pin", Protocol.hex(MessageDigest.getInstance("SHA-256").digest(certificate.getEncoded())));
        JSONObject wifi = NearbyLink.credentials();
        if (wifi != null) info.put("wifi", wifi);
        pairing = "EFB1:" + android.util.Base64.encodeToString(info.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8), android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP);
        sharing = true; busy = false; report("Ready. Scan this QR code on the receiving phone.", 0);
        final SSLServerSocket local = listener;
        new Thread(() -> {
            long expires = SystemClock.elapsedRealtime() + 30 * 60 * 1000L;
            try {
                local.setSoTimeout(1000);
                while (!cancelled && !local.isClosed()) {
                    if (SystemClock.elapsedRealtime() > expires) { stopNow("Sharing expired. Select files to start again."); break; }
                    try {
                        Socket client = local.accept();
                        sockets.add(client);
                        try { clients.execute(() -> { try { serve(client, metadata); } finally { sockets.remove(client); try { client.close(); } catch (Exception ignored) {} } }); }
                        catch (RejectedExecutionException e) { sockets.remove(client); client.close(); }
                    } catch (SocketTimeoutException ignored) {}
                }
            } catch (Exception e) { if (!cancelled) stopNow("Sharing stopped: " + friendly(e)); }
        }, "EFB-listen").start();
    }
    private void serve(Socket client, JSONArray metadata) {
        try {
            client.setSoTimeout(20000);
            DataInputStream in = new DataInputStream(client.getInputStream()); DataOutputStream out = new DataOutputStream(client.getOutputStream());
            JSONObject request = new JSONObject(Protocol.readText(in));
            if (!Protocol.same(token, request.optString("token"))) { Protocol.writeText(out, "{\"error\":\"Pairing rejected\"}"); return; }
            if ("LIST".equals(request.optString("op"))) { Protocol.writeText(out, new JSONObject().put("files", metadata).toString()); return; }
            if (!"GET".equals(request.optString("op"))) throw new IOException("Invalid request");
            int id = request.getInt("id"); if (id < 0 || id >= staged.size()) throw new IOException("Invalid file");
            JSONObject item = metadata.getJSONObject(id); Protocol.writeText(out, item.toString());
            long total = item.getLong("size"), sent = 0, started = SystemClock.elapsedRealtime();
            try (InputStream file = new FileInputStream(staged.get(id))) {
                byte[] b = new byte[65536]; int n;
                while ((n = file.read(b)) != -1) { check(); out.write(b, 0, n); sent += n; transferReport("Sending", item.getString("name"), sent, total, started); }
                out.flush();
            }
            JSONObject ack = new JSONObject(Protocol.readText(in));
            if (!"OK".equals(ack.optString("result"))) throw new IOException("Receiver did not verify file");
            report("Delivered and verified: " + item.getString("name"), 100);
        } catch (Exception e) { if (!cancelled) report("Transfer interrupted. Receiver can retry.", 0); }
    }
    private JSONObject decode(String value) throws Exception {
        if (value == null || !value.startsWith("EFB1:") || value.length() > 8192) throw new IOException("Scan an EasyFileBridge QR code");
        JSONObject j = new JSONObject(new String(android.util.Base64.decode(value.substring(5), android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP), java.nio.charset.StandardCharsets.UTF_8));
        if (j.getInt("v") != 1 || !j.getString("pin").matches("[a-f0-9]{64}") || !j.getString("token").matches("[a-f0-9-]{36}")) throw new IOException("Invalid pairing code");
        int port = j.getInt("port"); if (port < 1 || port > 65535) throw new IOException("Invalid port");
        JSONArray hosts = j.getJSONArray("hosts"); if (hosts.length() < 1 || hosts.length() > 8) throw new IOException("Invalid address");
        for (int i = 0; i < hosts.length(); i++) if (!Protocol.localAddress(hosts.getString(i))) throw new IOException("Use a local Wi-Fi connection");
        return j;
    }
    private SSLSocket connect(JSONObject info) throws Exception {
        final String pin = info.getString("pin");
        X509TrustManager trust = new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            public void checkClientTrusted(X509Certificate[] c, String a) throws java.security.cert.CertificateException { throw new java.security.cert.CertificateException("Unsupported"); }
            public void checkServerTrusted(X509Certificate[] c, String a) throws java.security.cert.CertificateException {
                try {
                    if (c.length < 1 || !Protocol.same(pin, Protocol.hex(MessageDigest.getInstance("SHA-256").digest(c[0].getEncoded())))) throw new Exception("QR fingerprint mismatch");
                } catch (Exception e) { throw new java.security.cert.CertificateException("Sender identity did not match QR code", e); }
            }
        };
        SSLContext tls = SSLContext.getInstance("TLS"); tls.init(null, new TrustManager[]{trust}, new SecureRandom());
        JSONArray hosts = info.getJSONArray("hosts"); Exception last = new IOException("Sender unavailable");
        for (int i = 0; i < hosts.length(); i++) {
            check(); SSLSocket s = (SSLSocket)tls.getSocketFactory().createSocket(); sockets.add(s);
            try {
                NearbyLink.bind(s);
                s.connect(new InetSocketAddress(hosts.getString(i), info.getInt("port")), 4000);
                s.setSoTimeout(20000); s.setEnabledProtocols(new String[]{"TLSv1.2"}); s.startHandshake(); return s;
            } catch (Exception e) { sockets.remove(s); s.close(); last = e; }
        }
        throw new IOException("Cannot reach sender. Connect both phones to the same Wi-Fi or hotspot.", last);
    }
    private void loadOffer(String code) throws Exception {
        incomingPair = ""; offers = new JSONArray(); JSONObject info = decode(code);
        try (SSLSocket s = connect(info)) {
            DataOutputStream out = new DataOutputStream(s.getOutputStream()); DataInputStream in = new DataInputStream(s.getInputStream());
            Protocol.writeText(out, new JSONObject().put("op", "LIST").put("token", info.getString("token")).toString());
            JSONArray files = new JSONObject(Protocol.readText(in)).getJSONArray("files"); validateFiles(files);
            offers = files; incomingPair = code; report("Choose files to receive", 0); sockets.remove(s);
        }
    }
    private void validateFiles(JSONArray files) throws Exception {
        if (files.length() < 1 || files.length() > Protocol.MAX_FILES) throw new IOException("Invalid file list");
        for (int i = 0; i < files.length(); i++) {
            JSONObject f = files.getJSONObject(i); long n = f.getLong("size");
            if (f.getInt("id") != i || n < 0 || n > Protocol.MAX_FILE_BYTES || !f.getString("sha256").matches("[a-f0-9]{64}") || f.getString("name").length() > 120) throw new IOException("Invalid file details");
        }
    }
    private void receive(String code, ArrayList<Integer> ids) throws Exception {
        if (ids == null || ids.isEmpty() || ids.size() > Protocol.MAX_FILES || !code.equals(incomingPair)) throw new IOException("Choose files first");
        JSONObject info = decode(code); JSONArray metadata = offers; int done = 0;
        for (int id : ids) {
            check(); if (id < 0 || id >= metadata.length()) throw new IOException("Invalid selection");
            JSONObject expected = metadata.getJSONObject(id); String name = Protocol.safeName(expected.getString("name"));
            File dir = new File(getFilesDir(), "received"); dir.mkdirs();
            File part = new File(dir, UUID.randomUUID() + ".part");
            try (SSLSocket s = connect(info)) {
                DataOutputStream out = new DataOutputStream(s.getOutputStream()); DataInputStream in = new DataInputStream(s.getInputStream());
                Protocol.writeText(out, new JSONObject().put("op", "GET").put("token", info.getString("token")).put("id", id).toString());
                JSONObject header = new JSONObject(Protocol.readText(in)); long total = expected.getLong("size");
                if (header.getLong("size") != total || !Protocol.same(header.getString("sha256"), expected.getString("sha256"))) throw new IOException("Sender file changed. Scan again.");
                if (dir.getUsableSpace() < total + 16L * 1024 * 1024) throw new IOException("Not enough storage space");
                MessageDigest digest = MessageDigest.getInstance("SHA-256"); long received = 0, started = SystemClock.elapsedRealtime();
                try (FileOutputStream file = new FileOutputStream(part)) {
                    byte[] b = new byte[65536];
                    while (received < total) {
                        check(); int n = in.read(b, 0, (int)Math.min(b.length, total - received));
                        if (n == -1) throw new EOFException("Connection interrupted");
                        file.write(b, 0, n); digest.update(b, 0, n); received += n; transferReport("Receiving " + (done + 1) + "/" + ids.size(), name, received, total, started);
                    }
                    file.getFD().sync();
                }
                if (!Protocol.same(Protocol.hex(digest.digest()), expected.getString("sha256"))) throw new IOException("File verification failed. Please retry.");
                File target = uniqueFile(dir, name); if (!part.renameTo(target)) throw new IOException("Cannot save received file");
                // A saved verified file remains valid even if the acknowledgement connection fails.
                try { Protocol.writeText(out, "{\"result\":\"OK\"}"); } catch (IOException ignored) {}
                done++; sockets.remove(s);
            } finally { if (part.exists()) part.delete(); }
        }
        incomingPair = ""; report("Received and verified " + done + " file(s). Open Files to view them.", 100);
    }
    private File uniqueFile(File dir, String name) {
        File f = new File(dir, name); int n = 1;
        while (f.exists()) f = new File(dir, (n++) + "-" + name);
        return f;
    }
    private void transferReport(String verb, String name, long n, long total, long start) {
        long elapsed = Math.max(1, SystemClock.elapsedRealtime() - start);
        report(verb + ": " + name + "\n" + Protocol.amount(n) + " / " + Protocol.amount(total) + " · " + Protocol.amount(n * 1000 / elapsed) + "/s", total == 0 ? 100 : (int)(n * 100 / total));
    }
    private synchronized void stopNow(String message) {
        cancelled = true; sharing = false; busy = false; pairing = ""; incomingPair = ""; status = message; progress = 0;
        try { if (listener != null) listener.close(); } catch (Exception ignored) {}
        for (Socket s : sockets) try { s.close(); } catch (Exception ignored) {}
        sockets.clear(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
    }
    private void clearDir(File dir) { File[] files = dir.listFiles(); if (files != null) for (File f : files) f.delete(); }
    @Override public void onDestroy() {
        cancelled = true; sharing = false; busy = false; pairing = "";
        if (senderSession) NearbyLink.close();
        try { if (listener != null) listener.close(); } catch (Exception ignored) {}
        for (Socket s : sockets) try { s.close(); } catch (Exception ignored) {}
        worker.shutdownNow(); if (wake != null && wake.isHeld()) wake.release();
        clients.shutdownNow();
        new Thread(() -> { try { worker.awaitTermination(30, TimeUnit.SECONDS); clients.awaitTermination(30, TimeUnit.SECONDS); } catch (InterruptedException ignored) {} clearDir(stageDir); stageDir.delete(); }, "EFB-cleanup").start();
        instance = null; super.onDestroy();
    }
    @Override public void onTimeout(int startId, int fgsType) { stopNow("Transfer time limit reached. Please start again."); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
