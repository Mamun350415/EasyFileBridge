package com.easyfilebridge.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

/** Bounded device-local history. No pairing secrets, network addresses or file contents. */
final class TransferHistory {
    private static final int LIMIT = 100;
    private TransferHistory() {}
    static synchronized JSONArray read(Context context) {
        try { return new JSONArray(context.getSharedPreferences("transfer_history", Context.MODE_PRIVATE).getString("entries", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    static synchronized void add(Context context, String direction, String name, long size, String outcome) {
        try {
            JSONArray previous = read(context), next = new JSONArray();
            next.put(new JSONObject().put("time", System.currentTimeMillis()).put("direction", direction)
                .put("name", name).put("size", size).put("outcome", outcome));
            for (int i = 0; i < previous.length() && next.length() < LIMIT; i++) next.put(previous.get(i));
            context.getSharedPreferences("transfer_history", Context.MODE_PRIVATE).edit().putString("entries", next.toString()).commit();
        } catch (Exception ignored) {}
    }
    static synchronized void clear(Context context) {
        context.getSharedPreferences("transfer_history", Context.MODE_PRIVATE).edit().remove("entries").commit();
    }
}
