package com.easyfilebridge.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.FileProvider;
import com.journeyapps.barcodescanner.*;
import com.google.zxing.BarcodeFormat;
import org.json.*;
import java.io.*;
import java.util.*;

public class MainActivity extends ComponentActivity {
    private final int blue = Color.rgb(36, 120, 255), ink = Color.rgb(28, 38, 59), muted = Color.rgb(102, 116, 137);
    private LinearLayout root, page;
    private TextView transferStatus;
    private ProgressBar meter;
    private LinearLayout qrBox;
    private String shownPair = "", offeredPair = "", screen = "home";
    private File exporting;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() { public void run() { refresh(); handler.postDelayed(this, 400); } };
    private ActivityResultLauncher<String[]> pickFiles;
    private ActivityResultLauncher<String[]> browseFiles;
    private ActivityResultLauncher<ScanOptions> scan;
    private ActivityResultLauncher<String> saveFile;
    private ActivityResultLauncher<String> permission;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        browseFiles = registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri == null) return;
            try { String type = getContentResolver().getType(uri); startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(uri, type == null ? "application/octet-stream" : type).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)); }
            catch (Exception e) { toast("No app can open this file"); }
        });
        pickFiles = registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), uris -> {
            if (uris.isEmpty()) return;
            if (uris.size() > Protocol.MAX_FILES) { toast("Select up to 200 files"); return; }
            ArrayList<String> values = new ArrayList<>();
            for (Uri uri : uris) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                values.add(uri.toString());
            }
            offeredPair = "";
            showSend(); startTask(new Intent(this, TransferService.class).setAction("SEND").putStringArrayListExtra("uris", values));
        });
        scan = registerForActivityResult(new ScanContract(), result -> {
            if (result.getContents() != null) connect(result.getContents());
        });
        saveFile = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"), uri -> {
            File source = exporting; exporting = null;
            if (uri == null || source == null) return;
            toast("Saving file...");
            new Thread(() -> {
                try (InputStream in = new FileInputStream(source); OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Cannot open destination");
                    byte[] bytes = new byte[65536]; int n;
                    while ((n = in.read(bytes)) != -1) out.write(bytes, 0, n);
                    runOnUiThread(() -> toast("Saved"));
                } catch (Exception e) {
                    try { android.provider.DocumentsContract.deleteDocument(getContentResolver(), uri); } catch (Exception ignored) {}
                    runOnUiThread(() -> toast("Could not save file. Try another folder."));
                }
            }, "EFB-export").start();
        });
        permission = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {});
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(247, 249, 253));
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            android.graphics.Insets bars = Build.VERSION.SDK_INT >= 30 ? insets.getInsets(WindowInsets.Type.systemBars()) : null;
            int top = bars == null ? insets.getSystemWindowInsetTop() : bars.top;
            int bottom = bars == null ? insets.getSystemWindowInsetBottom() : bars.bottom;
            root.setPadding(0, top, 0, bottom); return insets;
        });
        setContentView(root); root.requestApplyInsets();
        if (getPreferences(MODE_PRIVATE).getInt("agreement", 0) != 1) welcome(); else home();
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (!"home".equals(screen) && !"welcome".equals(screen)) home(); else finish();
            }
        });
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private void begin(String name, String title) {
        screen = name; root.removeAllViews(); transferStatus = null; meter = null; qrBox = null; shownPair = "";
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(24), dp(20), dp(24), dp(24));
        scroll.addView(page); root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        if (!"home".equals(name) && !"welcome".equals(name)) action("‹  Home", () -> home(), false);
        text(title, 28, ink, true);
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(8), 0, dp(8)); page.addView(t); return t;
    }
    private void gap(int height) { View v = new View(this); page.addView(v, new LinearLayout.LayoutParams(1, dp(height))); }
    private Button action(String label, Runnable runnable, boolean primary) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(16);
        b.setTextColor(primary ? Color.WHITE : blue); b.setBackground(background(primary ? blue : Color.rgb(229, 238, 255), 14));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, dp(54)); params.setMargins(0, dp(8), 0, dp(4)); page.addView(b, params);
        b.setOnClickListener(v -> runnable.run()); return b;
    }
    private void welcome() {
        begin("welcome", "Welcome to\nEasyFileBridge"); gap(20);
        text("Your files. A simpler way to share.", 22, ink, true);
        gap(12); text("Send and receive files with nearby devices using Wi-Fi or a hotspot. No account needed.", 17, muted, false);
        gap(16); text("Send  •  Receive  •  Files", 22, blue, true);
        gap(20); text("Read our Terms of Use and Privacy Policy before continuing.", 15, muted, false);
        action("Terms of Use", () -> policy(false), false);
        action("Privacy Policy", () -> policy(true), false);
        CheckBox agree = new CheckBox(this); agree.setText("I agree to the Terms of Use and Privacy Policy"); agree.setTextColor(ink); agree.setPadding(0, dp(16), 0, dp(8)); page.addView(agree);
        Button next = action("Agree and Continue", () -> {
            getPreferences(MODE_PRIVATE).edit().putInt("agreement", 1).apply(); home();
        }, true);
        next.setEnabled(false); next.setAlpha(.45f); agree.setOnCheckedChangeListener((b, checked) -> { next.setEnabled(checked); next.setAlpha(checked ? 1 : .45f); });
        action("Decline", () -> finish(), false);
    }
    private void policy(boolean privacy) {
        String message = privacy ?
            "EasyFileBridge stores your agreement on this device. Files you select are copied temporarily to app storage for sending. Received files are stored on this device and can be opened, exported or deleted.\n\nTransfers use the local network with TLS encryption and a QR certificate fingerprint. Share the pairing code only with your intended recipient. This version has no ads, analytics, accounts or remote file server.\n\nCamera access is used only to scan pairing QR codes. Notifications show transfer activity. File access is limited to files you choose and files received in the app. Temporary outgoing files are deleted when the transfer session closes normally; interrupted sessions may leave cached copies until you clear app storage.\n\nUninstalling the app deletes its private files, including received files that you have not exported. You can withdraw consent in Settings; this stops transfers. Revised policies will require renewed consent.\n\nPolicy version: 1.0. This policy describes this build only." :
            "Use EasyFileBridge to share files you own or have permission to share. The recipient can keep a copy once downloaded. Only share pairing codes with people you trust.\n\nBoth devices need a reachable local Wi-Fi or hotspot connection. Transfers depend on device storage, battery and network availability. Keep a backup of important files.\n\nYou may decline or withdraw consent and stop using the app. This build has no account, payment or advertising agreement.\n\nTerms version: 1.0. These terms are a starter draft. Publisher identity, contact and jurisdiction must be completed before public distribution.";
        TextView body = new TextView(this); body.setText(message); body.setTextSize(16); body.setTextColor(ink); body.setPadding(dp(24), dp(12), dp(24), dp(12));
        ScrollView scroll = new ScrollView(this); scroll.addView(body);
        new AlertDialog.Builder(this).setTitle(privacy ? "Privacy Policy" : "Terms of Use").setView(scroll).setPositiveButton("Close", null).show();
    }
    private void home() {
        begin("home", "EasyFileBridge"); text("Share nearby. Keep it simple.", 16, muted, false); gap(30);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER); page.addView(row);
        tile(row, "Send", "Choose files\nto send", 0, () -> chooseSend());
        tile(row, "Receive", "Get files from\nanother device", 1, () -> showReceive());
        tile(row, "Files", "Open your\nreceived files", 2, () -> files());
        gap(32);
        text("Nearby sharing", 20, ink, true);
        text("Connect both devices to the same Wi-Fi or hotspot. On the sender, tap Send. On the receiver, tap Receive and scan the QR code.", 16, muted, false);
        gap(16); text("Transfer status", 18, ink, true); statusViews();
        action("View current transfer", () -> { if (TransferService.sharing) showSend(); else showReceive(); }, false);
        gap(12); action("Settings & Privacy", () -> settings(), false);
    }
    private void tile(LinearLayout row, String label, String description, int type, Runnable click) {
        LinearLayout cell = new LinearLayout(this); cell.setOrientation(LinearLayout.VERTICAL); cell.setGravity(Gravity.CENTER);
        row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1));
        Icon icon = new Icon(type); icon.setContentDescription(label); icon.setFocusable(true); icon.setClickable(true);
        cell.addView(icon, new LinearLayout.LayoutParams(dp(76), dp(76)));
        TextView title = new TextView(this); title.setText(label); title.setTextSize(18); title.setTextColor(ink); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER); title.setPadding(0, dp(12), 0, dp(8)); cell.addView(title);
        TextView sub = new TextView(this); sub.setText(description); sub.setTextSize(12); sub.setTextColor(muted); sub.setGravity(Gravity.CENTER); cell.addView(sub);
        cell.setOnClickListener(v -> click.run()); icon.setOnClickListener(v -> click.run());
    }
    private class Icon extends View {
        final int type; final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Icon(int type) { super(MainActivity.this); this.type = type; }
        @Override protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight(); canvas.save(); canvas.scale(w/80f, h/80f);
            paint.setColor(blue); paint.setStyle(Paint.Style.FILL); canvas.drawCircle(40, 40, 39, paint); paint.setColor(Color.WHITE);
            Path path = new Path();
            if (type == 0) { path.moveTo(21,36); path.lineTo(61,22); path.lineTo(48,61); path.lineTo(37,46); path.lineTo(21,36); path.close(); canvas.drawPath(path,paint); paint.setColor(blue); paint.setStrokeWidth(3); canvas.drawLine(37,46,53,30,paint); }
            else if (type == 1) { canvas.drawRoundRect(23,48,57,60,3,3,paint); path.moveTo(35,23); path.lineTo(45,23); path.lineTo(45,39); path.lineTo(54,39); path.lineTo(40,52); path.lineTo(26,39); path.lineTo(35,39); path.close(); canvas.drawPath(path,paint); }
            else { canvas.drawRoundRect(21,31,60,58,4,4,paint); canvas.drawRoundRect(21,25,38,37,3,3,paint); }
            canvas.restore();
        }
    }
    private void chooseSend() {
        if (TransferService.busy || TransferService.sharing) {
            new AlertDialog.Builder(this).setTitle("Transfer active").setMessage("Stop the current transfer before selecting new files.").setPositiveButton("View transfer", (d,w) -> showSend()).setNegativeButton("Close", null).show(); return;
        }
        pickFiles.launch(new String[]{"*/*"});
    }
    private void statusViews() {
        transferStatus = text(TransferService.status, 15, muted, false);
        meter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); meter.setMax(100); page.addView(meter, new LinearLayout.LayoutParams(-1, dp(12)));
    }
    private void showSend() {
        begin("send", "Send files"); text("Scan this QR code with EasyFileBridge on the receiving device.", 16, muted, false);
        statusViews(); qrBox = new LinearLayout(this); qrBox.setOrientation(LinearLayout.VERTICAL); qrBox.setGravity(Gravity.CENTER); page.addView(qrBox);
        action("Choose files", () -> chooseSend(), true);
        action("Copy pairing code", () -> {
            if (TransferService.pairing.isEmpty()) { toast("Select files first"); return; }
            ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("EasyFileBridge", TransferService.pairing)); toast("Pairing code copied");
        }, false);
        action("Stop sharing", () -> { stopService(new Intent(this, TransferService.class)); TransferService.status = "Sharing stopped"; home(); }, false);
        text("Pairing expires after 30 minutes. Share the code only with your intended recipient.", 14, muted, false);
        text("On the other phone, open Receive and scan this QR code. Both phones must use the same Wi-Fi or hotspot.", 14, muted, false);
        refresh();
    }
    private void showReceive() {
        begin("receive", "Receive files"); text("Ask the sender to tap Send, then scan their QR code.", 16, muted, false);
        action("Scan QR code", () -> {
            ScanOptions options = new ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE).setPrompt("Scan the sender's EasyFileBridge QR code").setBeepEnabled(false).setOrientationLocked(false);
            scan.launch(options);
        }, true);
        action("Paste pairing code", () -> {
            EditText entry = new EditText(this); entry.setHint("EFB1:..."); entry.setSingleLine(false); entry.setPadding(dp(20),dp(16),dp(20),dp(16));
            new AlertDialog.Builder(this).setTitle("Pairing code").setView(entry).setPositiveButton("Connect", (d,w) -> connect(entry.getText().toString().trim())).setNegativeButton("Cancel", null).show();
        }, false);
        action("Choose files to receive", () -> offerDialog(), false);
        statusViews();
        action("Cancel transfer", () -> { stopService(new Intent(this, TransferService.class)); TransferService.incomingPair = ""; TransferService.status = "Transfer cancelled"; home(); }, false);
    }
    private void connect(String code) {
        if (!code.startsWith("EFB1:")) { toast("Use an EasyFileBridge pairing code"); return; }
        if (TransferService.sharing) {
            if (code.equals(TransferService.pairing)) { toast("Pairing code is valid. Receiving files requires a second device."); return; }
            toast("Stop sharing before receiving files"); return;
        }
        if (TransferService.busy) { toast("A transfer is already running"); return; }
        offeredPair = ""; TransferService.incomingPair = ""; showReceive();
        startTask(new Intent(this, TransferService.class).setAction("LIST").putExtra("pair", code));
    }
    private void offerDialog() {
        JSONArray entries = TransferService.offers; String pair = TransferService.incomingPair;
        if (pair.isEmpty() || entries.length() == 0) { toast("Scan the sender's QR code first"); return; }
        String[] labels = new String[entries.length()]; boolean[] chosen = new boolean[entries.length()]; Arrays.fill(chosen,true);
        try { for (int i=0;i<entries.length();i++) { JSONObject f=entries.getJSONObject(i); labels[i]=f.getString("name")+"  ·  "+Protocol.amount(f.getLong("size")); } }
        catch (Exception e) { toast("Scan again"); return; }
        new AlertDialog.Builder(this).setTitle("Choose files to receive").setMultiChoiceItems(labels,chosen,(d,index,value)->chosen[index]=value)
            .setPositiveButton("Receive",(d,w)->{
                ArrayList<Integer> ids=new ArrayList<>(); for(int i=0;i<chosen.length;i++) if(chosen[i]) ids.add(i);
                if(ids.isEmpty()) { toast("Choose at least one file"); return; }
                if(TransferService.busy || TransferService.sharing) { toast("Wait for the current transfer"); return; }
                startTask(new Intent(this,TransferService.class).setAction("RECEIVE").putExtra("pair",pair).putIntegerArrayListExtra("ids",ids));
            }).setNegativeButton("Cancel",null).show();
    }
    private void startTask(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) permission.launch(Manifest.permission.POST_NOTIFICATIONS);
        try { startForegroundService(intent); } catch (Exception e) { toast("Could not start transfer. Reopen the app and try again."); }
    }
    private void refresh() {
        if (transferStatus != null) transferStatus.setText(TransferService.status);
        if (meter != null) { meter.setProgress(TransferService.progress); meter.setIndeterminate(TransferService.busy && TransferService.progress == 0); }
        String code=TransferService.pairing;
        if(qrBox!=null && !shownPair.equals(code)) {
            shownPair=code; qrBox.removeAllViews();
            if(!code.isEmpty()) try {
                Bitmap bitmap=new BarcodeEncoder().encodeBitmap(code,BarcodeFormat.QR_CODE,600,600);
                ImageView image=new ImageView(this); image.setImageBitmap(bitmap); image.setContentDescription("Pairing QR code");
                qrBox.addView(image,new LinearLayout.LayoutParams(dp(250),dp(250)));
            } catch(Exception e) { toast("Use Copy pairing code instead"); }
        }
        String incoming=TransferService.incomingPair;
        if("receive".equals(screen) && !incoming.isEmpty() && !incoming.equals(offeredPair) && !TransferService.busy) { offeredPair=incoming; offerDialog(); }
    }
    private void files() {
        begin("files", "Files"); text("Received files stay on this device. Save important files to Downloads before uninstalling.", 15, muted, false);
        File dir=new File(getFilesDir(),"received"); File[] list=dir.listFiles((d,n)->!n.endsWith(".part"));
        if(list==null || list.length==0) text("No received files yet",18,muted,false);
        else {
            Arrays.sort(list,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
            for(File file:list) {
                action(file.getName()+"\n"+Protocol.amount(file.length()),()->{
                    new AlertDialog.Builder(this).setTitle(file.getName()).setItems(new String[]{"Open","Save to Downloads / another folder","Delete"},(d,index)->{
                        if(index==0) openFile(file);
                        else if(index==1) { exporting=file; saveFile.launch(file.getName()); }
                        else new AlertDialog.Builder(this).setTitle("Delete file?").setMessage(file.getName()).setPositiveButton("Delete",(x,w)->{ if(!file.delete()) toast("Could not delete file"); files(); }).setNegativeButton("Cancel",null).show();
                    }).show();
                },false);
            }
        }
        action("Browse phone files",()->{
            try { browseFiles.launch(new String[]{"*/*"}); }
            catch(Exception e) { toast("No file browser available"); }
        },true);
    }
    private void openFile(File file) {
        try {
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".files",file);
            String extension=android.webkit.MimeTypeMap.getFileExtensionFromUrl(Uri.encode(file.getName()));
            String mime=android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase(Locale.US));
            startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(uri,mime==null?"application/octet-stream":mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
        } catch(Exception e) { toast("No app can open this file. Use Save to export it."); }
    }
    private void settings() {
        begin("settings","Settings & Privacy"); text("EasyFileBridge 1.0.0",16,muted,false);
        action("Terms of Use",()->policy(false),false); action("Privacy Policy",()->policy(true),false);
        action("Wi-Fi settings",()->startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)),false);
        action("Hotspot settings",()->{ try { startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS)); } catch(Exception e) { toast("Open hotspot in your phone Settings"); } },false);
        action("Withdraw agreement",()->new AlertDialog.Builder(this).setTitle("Withdraw agreement?").setMessage("Transfers will stop. Your received files remain on this device until you delete them or uninstall the app.").setPositiveButton("Withdraw",(d,w)->{
            stopService(new Intent(this,TransferService.class)); getPreferences(MODE_PRIVATE).edit().remove("agreement").apply(); welcome();
        }).setNegativeButton("Cancel",null).show(),false);
    }
    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }
    @Override protected void onStart() { super.onStart(); handler.post(ticker); }
    @Override protected void onStop() { handler.removeCallbacks(ticker); super.onStop(); }
}
