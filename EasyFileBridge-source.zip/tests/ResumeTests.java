package com.easyfilebridge.app;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public final class ResumeTests {
    static int checks;
    static void require(boolean value, String label) { if (!value) throw new AssertionError(label); checks++; }
    interface Operation {void run() throws Exception;}
    static void rejects(Operation op) throws Exception { try {op.run(); throw new AssertionError("Expected IOException");} catch(IOException expected) {checks++;} }
    public static void main(String[] args) throws Exception {
        Path dir=Files.createTempDirectory("efb-resume-tests");
        try {
            byte[] data=new byte[2*1024*1024+17]; new Random(42).nextBytes(data);
            File source=dir.resolve("source.bin").toFile(); Files.write(source.toPath(),data);
            int checkpoint=65536*7+123;
            File part=dir.resolve("download.part").toFile(); Files.write(part.toPath(),Arrays.copyOf(data,checkpoint));
            String prefix=ResumeIO.hash(part,part.length(),()->{});
            long accepted=ResumeIO.acceptedOffset(source,part.length(),prefix,()->{});
            require(accepted==checkpoint,"saved prefix accepted");
            try(InputStream in=new FileInputStream(source);OutputStream out=new FileOutputStream(part,true)) {
                ResumeIO.skipFully(in,accepted); in.transferTo(out);
            }
            require(Arrays.equals(Files.readAllBytes(part.toPath()),data),"resumed file byte-for-byte correct");
            require(ResumeIO.hash(source,data.length,()->{}).equals(ResumeIO.hash(part,data.length,()->{})),"full SHA-256 correct");
            require(ResumeIO.acceptedOffset(source,data.length,ResumeIO.hash(part,data.length,()->{}),()->{})==data.length,"complete partial needs no duplicate data");
            Files.write(part.toPath(),Arrays.copyOf(data,checkpoint));
            try(RandomAccessFile file=new RandomAccessFile(part,"rw")) {file.seek(500);file.write(file.read()^127);}
            require(ResumeIO.acceptedOffset(source,checkpoint,ResumeIO.hash(part,checkpoint,()->{}),()->{})==0,"corrupted saved prefix restarts");
            require(ResumeIO.acceptedOffset(source,checkpoint,"bogus",()->{})==0,"wrong prefix restarts");
            require(ResumeIO.acceptedOffset(source,0,"",()->{})==0,"fresh transfer");
            rejects(()->ResumeIO.acceptedOffset(source,-1,"",()->{}));
            rejects(()->ResumeIO.acceptedOffset(source,data.length+1L,"",()->{}));
            rejects(()->ResumeIO.hash(source,100,()->{throw new IOException("Cancelled");}));
            rejects(()->ResumeIO.validateAccepted(100,101,data.length));
            ResumeIO.validateAccepted(100,0,data.length); checks++; // Older sender safely restarts.
            ResumeIO.validateAccepted(100,100,data.length); checks++;
            InputStream noSkip=new ByteArrayInputStream(new byte[]{1,2,3,4}) {public long skip(long count){return 0;}};
            ResumeIO.skipFully(noSkip,3); require(noSkip.read()==4,"skip fallback");
            rejects(()->ResumeIO.skipFully(new ByteArrayInputStream(new byte[]{1}),2));
            ByteArrayOutputStream framed=new ByteArrayOutputStream(); Protocol.writeText(new DataOutputStream(framed),"Resume ✓");
            require(Protocol.readText(new DataInputStream(new ByteArrayInputStream(framed.toByteArray()))).equals("Resume ✓"),"UTF-8 framing");
            ByteArrayOutputStream invalid=new ByteArrayOutputStream(); new DataOutputStream(invalid).writeInt(Protocol.MAX_JSON+1);
            rejects(()->Protocol.readText(new DataInputStream(new ByteArrayInputStream(invalid.toByteArray()))));
            require(Protocol.safeName("../danger\\name").indexOf('/')<0,"safe names");
            File empty=dir.resolve("empty").toFile(); Files.write(empty.toPath(),new byte[0]);
            require(ResumeIO.hash(empty,0,()->{}).equals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"),"empty file SHA-256");
            System.out.println("PASS: "+checks+" resume/integrity/protocol checks");
        } finally {try(var paths=Files.walk(dir)){paths.sorted(Comparator.reverseOrder()).forEach(path->{try{Files.delete(path);}catch(IOException e){throw new RuntimeException(e);}});}}
    }
}
