package com.easyfilebridge.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.ColorStateList;
import android.graphics.drawable.RippleDrawable;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.FileProvider;
import com.journeyapps.barcodescanner.*;
import com.google.zxing.BarcodeFormat;
import org.json.*;
import java.io.*;
import java.util.*;

public class MainActivity extends ComponentActivity {
    private int blue, ink, muted, surface, card, soft;
    private boolean dark;
    private LinearLayout root, page;
    private TextView transferStatus;
    private ProgressBar meter;
    private LinearLayout qrBox;
    private String shownPair = "", offeredPair = "", screen = "home";
    private File exporting;
    private boolean linking;
    private PeerFinder finder;
    private TextView nearbyStatus;
    private LinearLayout nearbyDevices;
    private ActivityResultLauncher<String[]> peerPermission;
    private Runnable afterPeerPermission;
    private Runnable afterWifiPermission;
    private ActivityResultLauncher<String[]> wifiPermission;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() { public void run() { refresh(); handler.postDelayed(this, 400); } };
    private ActivityResultLauncher<String[]> pickFiles;
    private ActivityResultLauncher<String[]> browseFiles;
    private ActivityResultLauncher<ScanOptions> scan;
    private ActivityResultLauncher<String> saveFile;
    private ActivityResultLauncher<String> permission;

    @Override public void onCreate(Bundle state) {
        String appearance = getPreferences(MODE_PRIVATE).getString("appearance", "system");
        dark = "dark".equals(appearance) || ("system".equals(appearance) && (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
        setTheme(dark ? R.style.AppThemeDark : R.style.AppThemeLight);
        super.onCreate(state);
        blue = Color.rgb(36, 120, 255);
        ink = Color.parseColor(dark ? "#F1F5FF" : "#1C263B");
        muted = Color.parseColor(dark ? "#B5C1D5" : "#526176");
        surface = Color.parseColor(dark ? "#101722" : "#F7F9FD");
        card = Color.parseColor(dark ? "#1C2738" : "#FFFFFF");
        soft = Color.parseColor(dark ? "#203450" : "#E5EEFF");
        getWindow().setStatusBarColor(surface); getWindow().setNavigationBarColor(surface);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        peerPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), granted -> {
            Runnable next = afterPeerPermission; afterPeerPermission = null;
            if (hasPeerPermissions()) { if (next != null) next.run(); }
            else if (nearbyStatus != null) nearbyStatus.setText("Nearby permission denied. Use Scan QR code instead.");
        });
        wifiPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), granted -> {
            Runnable next = afterWifiPermission; afterWifiPermission = null;
            if (hasWifiPermissions()) { if (next != null) next.run(); }
            else { linking = false; toast("Permission denied. You can still use an existing Wi-Fi connection."); }
        });
        browseFiles = registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri == null) return;
            try { String type = getContentResolver().getType(uri); startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(uri, type == null ? "application/octet-stream" : type).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)); }
            catch (Exception e) { toast("No app can open this file"); }
        });
        pickFiles = registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), uris -> {
            if (uris.isEmpty()) { NearbyLink.close(); TransferService.status = "Ready to transfer"; home(); return; }
            if (uris.size() > Protocol.MAX_FILES) { NearbyLink.close(); toast("Select up to 200 files"); return; }
            ArrayList<String> values = new ArrayList<>();
            for (Uri uri : uris) {
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                values.add(uri.toString());
            }
            offeredPair = "";
            showSend(); startTask(new Intent(this, TransferService.class).setAction("SEND").putStringArrayListExtra("uris", values));
        });
        scan = registerForActivityResult(new ScanContract(), result -> {
            if (result.getContents() != null) connect(result.getContents());
        });
        saveFile = registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"), uri -> {
            File source = exporting; exporting = null;
            if (uri == null || source == null) return;
            toast("Saving file...");
            new Thread(() -> {
                try (InputStream in = new FileInputStream(source); OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IOException("Cannot open destination");
                    byte[] bytes = new byte[65536]; int n;
                    while ((n = in.read(bytes)) != -1) out.write(bytes, 0, n);
                    runOnUiThread(() -> toast("Saved"));
                } catch (Exception e) {
                    try { android.provider.DocumentsContract.deleteDocument(getContentResolver(), uri); } catch (Exception ignored) {}
                    runOnUiThread(() -> toast("Could not save file. Try another folder."));
                }
            }, "EFB-export").start();
        });
        permission = registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {});
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(surface);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            android.graphics.Insets bars = Build.VERSION.SDK_INT >= 30 ? insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout()) : null;
            int top = bars == null ? insets.getSystemWindowInsetTop() : bars.top;
            int bottom = bars == null ? insets.getSystemWindowInsetBottom() : bars.bottom;
            int left = bars == null ? insets.getSystemWindowInsetLeft() : bars.left;
            int right = bars == null ? insets.getSystemWindowInsetRight() : bars.right;
            root.setPadding(left, top, right, bottom); return insets;
        });
        setContentView(root); root.requestApplyInsets();
        if (state != null && state.getString("exporting") != null) exporting = new File(state.getString("exporting"));
        if (getPreferences(MODE_PRIVATE).getInt("agreement", 0) != 4) welcome();
        else {
            String restored = state == null ? "home" : state.getString("screen", "home");
            if ("settings".equals(restored)) settings();
            else if ("send".equals(restored)) showSend();
            else if ("receive".equals(restored)) showReceive();
            else if ("files".equals(restored)) files();
            else home();
        }
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (!"home".equals(screen) && !"welcome".equals(screen)) home(); else finish();
            }
        });
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private void begin(String name, String title) {
        if (!name.equals(screen)) stopFinder();
        nearbyStatus = null; nearbyDevices = null;
        screen = name; root.removeAllViews(); transferStatus = null; meter = null; qrBox = null; shownPair = "";
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(24), dp(20), dp(24), dp(24));
        scroll.setClipToPadding(false);
        LinearLayout holder = new LinearLayout(this); holder.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        int available = getResources().getConfiguration().screenWidthDp;
        holder.addView(page, new LinearLayout.LayoutParams(available > 640 ? dp(640) : -1, -2));
        scroll.addView(holder); root.addView(scroll, new LinearLayout.LayoutParams(-1, -1));
        if (!"home".equals(name) && !"welcome".equals(name)) action("‹  Home", () -> home(), false);
        if ("home".equals(name)) {
            LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
            TextView heading = new TextView(this); heading.setText(title); heading.setTextSize(28);
            heading.setTextColor(ink); heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            heading.setPadding(0, dp(8), dp(8), dp(8));
            header.addView(heading, new LinearLayout.LayoutParams(0, -2, 1));
            MenuIcon menu = new MenuIcon(); menu.setContentDescription("Open menu");
            menu.setFocusable(true); menu.setClickable(true);
            menu.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(45, 128, 170, 255)), background(card, 14), null));
            header.addView(menu, new LinearLayout.LayoutParams(dp(48), dp(48)));
            menu.setOnClickListener(v -> {
                PopupMenu popup = new PopupMenu(this, menu);
                popup.getMenu().add(0, 1, 0, "Current transfer");
                popup.getMenu().add(0, 2, 1, "Settings & Privacy");
                popup.setOnMenuItemClickListener(item -> {
                    if (item.getItemId() == 1) {
                        if (TransferService.sharing || (linking && TransferService.incomingPair.isEmpty())) showSend(); else showReceive();
                    } else settings();
                    return true;
                });
                popup.show();
            });
            page.addView(header);
        } else text(title, 28, ink, true);
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(8), 0, dp(8)); page.addView(t); return t;
    }
    private void gap(int height) { View v = new View(this); page.addView(v, new LinearLayout.LayoutParams(1, dp(height))); }
    private Button action(String label, Runnable runnable, boolean primary) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(16);
        b.setTextColor(primary ? Color.WHITE : (dark ? Color.rgb(146, 190, 255) : Color.rgb(24, 87, 185)));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(45, 128, 170, 255)), background(primary ? blue : soft, 16), null));
        b.setMinHeight(dp(56)); b.setMinimumHeight(dp(56)); b.setPadding(dp(18), dp(14), dp(18), dp(14));
        b.setGravity(Gravity.CENTER); b.setElevation(0);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2); params.setMargins(0, dp(8), 0, dp(4)); page.addView(b, params);
        b.setOnClickListener(v -> runnable.run()); return b;
    }
    private void welcome() {
        begin("welcome", "Welcome to\nEasyFileBridge"); gap(20);
        text("Your files. A simpler way to share.", 22, ink, true);
        gap(12); text("Send and receive files with nearby devices using Wi-Fi or a hotspot. No account needed.", 17, muted, false);
        gap(16); text("Send  •  Receive  •  Files", 22, blue, true);
        gap(20); text("Read our Terms of Use and Privacy Policy before continuing.", 15, muted, false);
        action("Terms of Use", () -> policy(false), false);
        action("Privacy Policy", () -> policy(true), false);
        CheckBox agree = new CheckBox(this); agree.setText("I agree to the Terms of Use and Privacy Policy"); agree.setTextColor(ink); agree.setPadding(0, dp(16), 0, dp(8)); page.addView(agree);
        Button next = action("Agree and Continue", () -> {
            getPreferences(MODE_PRIVATE).edit().putInt("agreement", 4).apply(); home();
        }, true);
        next.setEnabled(false); next.setAlpha(.45f); agree.setOnCheckedChangeListener((b, checked) -> { next.setEnabled(checked); next.setAlpha(checked ? 1 : .45f); });
        action("Decline", () -> finish(), false);
    }
    private void policy(boolean privacy) {
        String message = privacy ?
            "EasyFileBridge stores your agreement on this device. Files you select are copied temporarily to app storage for sending. Received files are stored on this device and can be opened, exported or deleted.\n\nTransfers use the local network with TLS encryption and a QR certificate fingerprint. Share the pairing code only with your intended recipient. This version has no ads, publisher-operated analytics, accounts or remote file server. Optional nearby phone discovery uses Google Play services Nearby Connections. It shares your device model with nearby app users and exchanges pairing details only after both phones approve a matching verification code. Google may collect Nearby performance and device diagnostics according to your Google Usage & diagnostics setting. QR pairing does not require Nearby discovery.\n\nCamera access is used only to scan pairing QR codes. Nearby Wi-Fi permission lets the app create a temporary hotspot and connect to the sender. Android may require Location permission and Location to be enabled for Wi-Fi connection APIs; the app does not collect or store your location. QR codes include temporary hotspot credentials and must only be shown to your intended recipient. Notifications show transfer activity. File access is limited to files you choose and files received in the app. Temporary outgoing files are deleted when the transfer session closes normally; interrupted sessions may leave cached copies until you clear app storage.\n\nUninstalling the app deletes its private files, including received files that you have not exported. You can withdraw consent in Settings; this stops transfers. Revised policies will require renewed consent.\n\nPublisher: Mamun Or Rashid.\nContact for privacy and support: mamunahmed350415@gmail.com\n\nPolicy version: 1.3. This policy describes this build only." :
            "Use EasyFileBridge to share files you own or have permission to share. The recipient can keep a copy once downloaded. Only share pairing codes with people you trust.\n\nBoth devices need a reachable local Wi-Fi or hotspot connection. On supported devices, the app can create a temporary hotspot and request connection after QR scanning. Android may ask for permissions or changes to Wi-Fi and Location settings. Transfers depend on device storage, battery and network availability. Keep a backup of important files.\n\nYou may decline or withdraw consent and stop using the app. This build has no account, payment or advertising agreement.\n\nPublisher: Mamun Or Rashid.\nContact for support and questions about these terms: mamunahmed350415@gmail.com\n\nTerms version: 1.3.";
        TextView body = new TextView(this); body.setText(message); body.setTextSize(16); body.setTextColor(ink); body.setPadding(dp(24), dp(12), dp(24), dp(12));
        ScrollView scroll = new ScrollView(this); scroll.addView(body);
        new AlertDialog.Builder(this).setTitle(privacy ? "Privacy Policy" : "Terms of Use").setView(scroll).setPositiveButton("Close", null).show();
    }
    private void home() {
        begin("home", "EasyFileBridge"); text("Share nearby. Keep it simple.", 16, muted, false); gap(30);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER); page.addView(row);
        boolean compact = getResources().getConfiguration().screenWidthDp < 340 || getResources().getConfiguration().fontScale > 1.3f;
        if (compact) row.setOrientation(LinearLayout.VERTICAL);
        tile(row, "Send", "Choose files to send", 0, () -> chooseSend());
        tile(row, "Receive", "Get files from another device", 1, () -> showReceive());
        tile(row, "Files", "Open received files", 2, () -> files());
        gap(32);
        text("Nearby sharing", 20, ink, true);
        text("Tap Send and allow a temporary hotspot, then choose your files. On the other phone, tap Receive, scan the QR code and approve Connect. No internet needed.", 16, muted, false);
        gap(16); text("Transfer status", 18, ink, true); statusViews();

    }
    private void tile(LinearLayout row, String label, String description, int type, Runnable click) {
        LinearLayout cell = new LinearLayout(this); cell.setOrientation(LinearLayout.VERTICAL); cell.setGravity(Gravity.CENTER);
        boolean stacked = row.getOrientation() == LinearLayout.VERTICAL;
        LinearLayout.LayoutParams tileParams = new LinearLayout.LayoutParams(stacked ? -1 : 0, -2, stacked ? 0 : 1);
        tileParams.setMargins(dp(4), dp(4), dp(4), dp(4)); row.addView(cell, tileParams);
        cell.setPadding(dp(6), dp(16), dp(6), dp(16));
        cell.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(45, 128, 170, 255)), background(card, 20), null));
        cell.setFocusable(true); cell.setClickable(true); cell.setContentDescription(label + ". " + description);
        cell.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        Icon icon = new Icon(type); icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        cell.addView(icon, new LinearLayout.LayoutParams(dp(76), dp(76)));
        TextView title = new TextView(this); title.setText(label); title.setTextSize(18); title.setTextColor(ink); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER); title.setPadding(0, dp(12), 0, dp(8)); cell.addView(title);
        TextView sub = new TextView(this); sub.setText(description); sub.setTextSize(14); sub.setTextColor(muted); sub.setGravity(Gravity.CENTER); cell.addView(sub);
        title.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO); sub.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        cell.setOnClickListener(v -> click.run());
    }
    private class MenuIcon extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        MenuIcon() { super(MainActivity.this); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas); paint.setColor(ink);
            float x = getWidth() / 2f, y = getHeight() / 2f;
            float radius = dp(2);
            canvas.drawCircle(x, y - dp(7), radius, paint);
            canvas.drawCircle(x, y, radius, paint);
            canvas.drawCircle(x, y + dp(7), radius, paint);
        }
    }
    private class Icon extends View {
        final int type; final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Icon(int type) { super(MainActivity.this); this.type = type; }
        @Override protected void onDraw(Canvas canvas) {
            float w = getWidth(), h = getHeight(); canvas.save(); canvas.scale(w/80f, h/80f);
            paint.setColor(blue); paint.setStyle(Paint.Style.FILL); canvas.drawCircle(40, 40, 39, paint); paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(3.5f);
            paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
            Path path = new Path();
            if (type == 0) {
                path.moveTo(22,35); path.lineTo(59,22); path.lineTo(46,59); path.lineTo(36,45); path.close();
                canvas.drawPath(path,paint); canvas.drawLine(36,45,59,22,paint);
            } else if (type == 1) {
                canvas.drawLine(40,22,40,46,paint); canvas.drawLine(30,36,40,46,paint); canvas.drawLine(50,36,40,46,paint);
                path.moveTo(23,46); path.lineTo(23,58); path.lineTo(57,58); path.lineTo(57,46); canvas.drawPath(path,paint);
            } else {
                path.moveTo(22,58); path.lineTo(22,26); path.lineTo(36,26); path.lineTo(42,32); path.lineTo(58,32); path.lineTo(58,58); path.close();
                canvas.drawPath(path,paint); canvas.drawLine(23,38,57,38,paint);
            }
            canvas.restore();
        }
    }
    private void chooseSend() {
        if (TransferService.busy || TransferService.sharing) {
            new AlertDialog.Builder(this).setTitle("Transfer active").setMessage("Stop the current transfer before selecting new files.").setPositiveButton("View transfer", (d,w) -> showSend()).setNegativeButton("Close", null).show(); return;
        }
        if (linking) { toast("Connection setup is already in progress"); return; }
        new AlertDialog.Builder(this).setTitle("Allow temporary hotspot?")
            .setMessage("EasyFileBridge will create a temporary hotspot for nearby file sharing. Your recipient can scan the QR code to connect. No mobile data is needed.")
            .setPositiveButton("Allow", (d,w) -> withWifiPermissions(() -> {
                linking = true; TransferService.status = "Starting temporary hotspot..."; showSend();
                NearbyLink.start(this, new NearbyLink.Result() {
                    public void ready() { linking = false; if (!isFinishing() && !isDestroyed()) pickFiles.launch(new String[]{"*/*"}); else NearbyLink.close(); }
                    public void failed(String message) { linking = false; TransferService.status = message; if (!isFinishing() && !isDestroyed()) connectionError(message); }
                });
            }))
            .setNeutralButton("Use existing Wi-Fi", (d,w) -> { NearbyLink.close(); pickFiles.launch(new String[]{"*/*"}); })
            .setNegativeButton("Cancel", null).show();
    }
    private void stopFinder() {
        if (finder != null) { finder.close(); finder = null; }
    }
    private String[] peerPermissions() {
        ArrayList<String> values = new ArrayList<>();
        values.add(Manifest.permission.ACCESS_COARSE_LOCATION); values.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= 31) {
            values.add(Manifest.permission.BLUETOOTH_SCAN); values.add(Manifest.permission.BLUETOOTH_CONNECT); values.add(Manifest.permission.BLUETOOTH_ADVERTISE);
        }
        if (Build.VERSION.SDK_INT >= 33) values.add(Manifest.permission.NEARBY_WIFI_DEVICES);
        return values.toArray(new String[0]);
    }
    private boolean hasPeerPermissions() {
        for (String value : peerPermissions()) if (checkSelfPermission(value) != PackageManager.PERMISSION_GRANTED) return false;
        return true;
    }
    private void startFinder(boolean sender) {
        if (linking || TransferService.busy) { toast("Wait for connection setup or the current transfer"); return; }
        if (sender && (!TransferService.sharing || TransferService.pairing.isEmpty())) { toast("Choose files and wait for the QR code first"); return; }
        if (!sender && TransferService.sharing) { toast("Stop sharing before receiving files"); return; }
        if (!hasPeerPermissions()) {
            afterPeerPermission = () -> { if ((sender && "send".equals(screen)) || (!sender && "receive".equals(screen))) startFinder(sender); };
            peerPermission.launch(peerPermissions()); return;
        }
        android.bluetooth.BluetoothManager manager = (android.bluetooth.BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        android.bluetooth.BluetoothAdapter adapter = manager == null ? null : manager.getAdapter();
        android.net.wifi.WifiManager wifi = (android.net.wifi.WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);
        if (adapter == null || !adapter.isEnabled()) {
            new AlertDialog.Builder(this).setTitle("Turn on Bluetooth")
                .setMessage("Enable Bluetooth, return here and try nearby pairing again. You can use the QR code instead.")
                .setPositiveButton("Bluetooth settings", (d,w) -> startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)))
                .setNegativeButton("Use QR code", null).show(); return;
        }
        if (!sender && (wifi == null || !wifi.isWifiEnabled())) {
            new AlertDialog.Builder(this).setTitle("Turn on Wi-Fi").setMessage("Enable Wi-Fi to find nearby senders. Internet is not required.")
                .setPositiveButton("Wi-Fi settings", (d,w) -> startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)))
                .setNegativeButton("Cancel", null).show(); return;
        }
        stopFinder(); if (nearbyDevices != null) nearbyDevices.removeAllViews();
        if (nearbyStatus != null) nearbyStatus.setText(sender ? "Making this phone visible..." : "Searching for nearby senders...");
        finder = new PeerFinder(this, sender ? TransferService.pairing : "", new PeerFinder.Events() {
            public void message(String message) { if (nearbyStatus != null) nearbyStatus.setText(message); }
            public void devices(Map<String,String> devices) {
                if (nearbyDevices == null) return; nearbyDevices.removeAllViews();
                if (nearbyStatus != null) nearbyStatus.setText(devices.isEmpty() ? "No sender found yet. Keep the sender visible, or scan its QR code." : "Tap your sender's phone, then compare the code on both devices.");
                for (Map.Entry<String,String> entry : devices.entrySet()) {
                    Button device = new Button(MainActivity.this); device.setAllCaps(false); device.setText(entry.getValue());
                    device.setTextColor(ink); device.setTextSize(16); device.setMinHeight(dp(56));
                    device.setPadding(dp(12),dp(12),dp(12),dp(12)); device.setBackground(background(soft,14));
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1,-2); params.setMargins(0,dp(4),0,dp(4)); nearbyDevices.addView(device,params);
                    device.setOnClickListener(v -> { if (finder != null) finder.choose(entry.getKey()); });
                }
            }
            public void paired(String code) { if (!isFinishing() && !isDestroyed()) connect(code); }
        });
        finder.start();
    }
    private boolean hasWifiPermissions() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            && (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED);
    }
    private void withWifiPermissions(Runnable next) {
        if (hasWifiPermissions()) { next.run(); return; }
        afterWifiPermission = next;
        wifiPermission.launch(Build.VERSION.SDK_INT >= 33 ? new String[]{Manifest.permission.NEARBY_WIFI_DEVICES, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION} : new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION});
    }
    private void connectionError(String message) {
        new AlertDialog.Builder(this).setTitle("Connection setup").setMessage(message)
            .setPositiveButton("OK", null).setNeutralButton("Wi-Fi settings", (d,w) -> startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS))).show();
    }
    private void statusViews() {
        transferStatus = text(TransferService.status, 15, muted, false);
        meter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); meter.setMax(100); meter.setProgressTintList(ColorStateList.valueOf(blue)); meter.setIndeterminateTintList(ColorStateList.valueOf(blue));
        meter.setProgressBackgroundTintList(ColorStateList.valueOf(soft));
        page.addView(meter, new LinearLayout.LayoutParams(-1, dp(12)));
    }
    private void showSend() {
        begin("send", "Send files"); text("Scan this QR code with EasyFileBridge on the receiving device.", 16, muted, false);
        statusViews(); qrBox = new LinearLayout(this); qrBox.setOrientation(LinearLayout.VERTICAL); qrBox.setGravity(Gravity.CENTER); page.addView(qrBox);
        action("Show to nearby phones", () -> startFinder(true), true);
        nearbyStatus = text("Use nearby pairing, or let the receiver scan the QR code.", 14, muted, false);
        action("Choose files", () -> chooseSend(), false);
        action("Copy pairing code", () -> {
            if (TransferService.pairing.isEmpty()) { toast("Select files first"); return; }
            ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("EasyFileBridge", TransferService.pairing)); toast("Pairing code copied");
        }, false);
        action("Stop sharing", () -> { stopFinder(); NearbyLink.close(); linking = false; stopService(new Intent(this, TransferService.class)); TransferService.status = "Sharing stopped"; home(); }, false);
        text("Pairing expires after 30 minutes. Share the code only with your intended recipient.", 14, muted, false);
        text("On the other phone, open Receive and scan this QR code. Approve Connect on the receiving phone to join the temporary hotspot. If you chose existing Wi-Fi, both phones must already be connected to that network.", 14, muted, false);
        refresh();
    }
    private void showReceive() {
        begin("receive", "Receive files"); text("Find the sender nearby, or scan their QR code if you cannot find them.", 16, muted, false);
        action("Find nearby phones", () -> startFinder(false), true);
        nearbyStatus = text("On the sender, choose files and tap Show to nearby phones. Keep Bluetooth and Wi-Fi on.", 14, muted, false);
        nearbyDevices = new LinearLayout(this); nearbyDevices.setOrientation(LinearLayout.VERTICAL); page.addView(nearbyDevices);
        text("Cannot find the sender?", 18, ink, true);
        action("Scan QR code", () -> {
            stopFinder();
            ScanOptions options = new ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE).setPrompt("Scan the sender's EasyFileBridge QR code").setBeepEnabled(false).setOrientationLocked(false);
            scan.launch(options);
        }, true);
        action("Paste pairing code", () -> {
            EditText entry = new EditText(this); entry.setHint("EFB1:..."); entry.setSingleLine(false); entry.setPadding(dp(20),dp(16),dp(20),dp(16));
            new AlertDialog.Builder(this).setTitle("Pairing code").setView(entry).setPositiveButton("Connect", (d,w) -> connect(entry.getText().toString().trim())).setNegativeButton("Cancel", null).show();
        }, false);
        action("Choose files to receive", () -> offerDialog(), false);
        statusViews();
        action("Cancel transfer", () -> { stopFinder(); NearbyLink.close(); linking = false; stopService(new Intent(this, TransferService.class)); TransferService.incomingPair = ""; TransferService.status = "Transfer cancelled"; home(); }, false);
    }
    private void connect(String code) {
        stopFinder();
        if (!code.startsWith("EFB1:")) { toast("Use an EasyFileBridge pairing code"); return; }
        if (TransferService.sharing) {
            if (code.equals(TransferService.pairing)) { toast("Pairing code is valid. Receiving files requires a second device."); return; }
            toast("Stop sharing before receiving files"); return;
        }
        if (TransferService.busy) { toast("A transfer is already running"); return; }
        if (linking) { toast("Connection setup is already in progress"); return; }
        final JSONObject info;
        try { info = NearbyLink.read(code); } catch (Exception e) { toast("Invalid EasyFileBridge pairing code"); return; }
        offeredPair = ""; TransferService.incomingPair = ""; showReceive();
        Runnable load = () -> { if (!isFinishing() && !isDestroyed()) startTask(new Intent(this, TransferService.class).setAction("LIST").putExtra("pair", code)); else NearbyLink.close(); };
        if (!info.has("wifi")) { NearbyLink.close(); load.run(); return; }
        if (Build.VERSION.SDK_INT < 29) {
            JSONObject wifi = info.optJSONObject("wifi");
            new AlertDialog.Builder(this).setTitle("Connect to sender")
                .setMessage("On this Android version, connect in Wi-Fi settings first.\n\nNetwork: " + wifi.optString("ssid") + "\nPassword: " + wifi.optString("password"))
                .setPositiveButton("I am connected", (d,w) -> load.run())
                .setNeutralButton("Wi-Fi settings", (d,w) -> startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS))).setNegativeButton("Cancel", null).show(); return;
        }
        new AlertDialog.Builder(this).setTitle("Connect to sender's hotspot?")
            .setMessage("Allow EasyFileBridge to request a local Wi-Fi connection. Approve Connect on the Android prompt. This hotspot has no internet.")
            .setPositiveButton("Allow", (d,w) -> withWifiPermissions(() -> {
                linking = true; TransferService.status = "Approve Connect to join the sender's hotspot.";
                NearbyLink.join(this, info, new NearbyLink.Result() {
                    public void ready() { linking = false; load.run(); }
                    public void failed(String message) { linking = false; TransferService.status = message; if (!isFinishing() && !isDestroyed()) receiverConnectionError(message, info, load); }
                });
            })).setNegativeButton("Cancel", null).show();
    }
    private void receiverConnectionError(String message, JSONObject info, Runnable load) {
        JSONObject wifi = info.optJSONObject("wifi");
        new AlertDialog.Builder(this).setTitle("Hotspot connection failed").setMessage(message)
            .setPositiveButton("OK", null)
            .setNeutralButton("Connect manually", (d,w) -> {
                if (wifi == null) return;
                new AlertDialog.Builder(this).setTitle("Sender's hotspot")
                    .setMessage("Join this network in Wi-Fi settings. Choose Stay connected if Android says No internet. Return here and tap I am connected.\n\nNetwork: " + wifi.optString("ssid") + "\nPassword: " + wifi.optString("password"))
                    .setNeutralButton("Wi-Fi settings", (dialog,which) -> {
                        startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS));
                        new AlertDialog.Builder(this).setTitle("After connecting")
                            .setMessage("Return after joining the sender's hotspot, then continue.")
                            .setPositiveButton("I am connected", (x,y) -> { NearbyLink.close(); load.run(); })
                            .setNegativeButton("Cancel", null).show();
                    })
                    .setPositiveButton("I am connected", (x,y) -> { NearbyLink.close(); load.run(); })
                    .setNegativeButton("Cancel", null).show();
            }).show();
    }
    private void offerDialog() {
        JSONArray entries = TransferService.offers; String pair = TransferService.incomingPair;
        if (pair.isEmpty() || entries.length() == 0) { toast("Scan the sender's QR code first"); return; }
        String[] labels = new String[entries.length()]; boolean[] chosen = new boolean[entries.length()]; Arrays.fill(chosen,true);
        try { for (int i=0;i<entries.length();i++) { JSONObject f=entries.getJSONObject(i); labels[i]=f.getString("name")+"  ·  "+Protocol.amount(f.getLong("size")); } }
        catch (Exception e) { toast("Scan again"); return; }
        new AlertDialog.Builder(this).setTitle("Choose files to receive").setMultiChoiceItems(labels,chosen,(d,index,value)->chosen[index]=value)
            .setPositiveButton("Receive",(d,w)->{
                ArrayList<Integer> ids=new ArrayList<>(); for(int i=0;i<chosen.length;i++) if(chosen[i]) ids.add(i);
                if(ids.isEmpty()) { toast("Choose at least one file"); return; }
                if(TransferService.busy || TransferService.sharing) { toast("Wait for the current transfer"); return; }
                startTask(new Intent(this,TransferService.class).setAction("RECEIVE").putExtra("pair",pair).putIntegerArrayListExtra("ids",ids));
            }).setNegativeButton("Cancel",null).show();
    }
    private void startTask(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) permission.launch(Manifest.permission.POST_NOTIFICATIONS);
        try { startForegroundService(intent); } catch (Exception e) { toast("Could not start transfer. Reopen the app and try again."); }
    }
    private void refresh() {
        if (finder != null && "send".equals(screen) && !TransferService.sharing && !TransferService.busy) stopFinder();
        if (transferStatus != null) transferStatus.setText(TransferService.status);
        if (meter != null) { meter.setProgress(TransferService.progress); meter.setIndeterminate(TransferService.busy && TransferService.progress == 0); }
        String code=TransferService.pairing;
        if(qrBox!=null && !shownPair.equals(code)) {
            shownPair=code; qrBox.removeAllViews();
            if(!code.isEmpty()) try {
                Bitmap bitmap=new BarcodeEncoder().encodeBitmap(code,BarcodeFormat.QR_CODE,600,600);
                ImageView image=new ImageView(this); image.setImageBitmap(bitmap); image.setContentDescription("Pairing QR code");
                int qrSize = dp(Math.min(280, Math.max(120, getResources().getConfiguration().screenWidthDp - 64)));
                image.setBackgroundColor(Color.WHITE); image.setPadding(dp(8), dp(8), dp(8), dp(8));
                image.setScaleType(ImageView.ScaleType.FIT_CENTER);
                qrBox.addView(image,new LinearLayout.LayoutParams(qrSize,qrSize));
            } catch(Exception e) { toast("Use Copy pairing code instead"); }
        }
        String incoming=TransferService.incomingPair;
        if("receive".equals(screen) && !incoming.isEmpty() && !incoming.equals(offeredPair) && !TransferService.busy) { offeredPair=incoming; offerDialog(); }
    }
    private void files() {
        begin("files", "Files"); text("Received files stay on this device. Save important files to Downloads before uninstalling.", 15, muted, false);
        File dir=new File(getFilesDir(),"received"); File[] list=dir.listFiles((d,n)->!n.endsWith(".part"));
        if(list==null || list.length==0) text("No received files yet",18,muted,false);
        else {
            Arrays.sort(list,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
            for(File file:list) {
                action(file.getName()+"\n"+Protocol.amount(file.length()),()->{
                    new AlertDialog.Builder(this).setTitle(file.getName()).setItems(new String[]{"Open","Save to Downloads / another folder","Delete"},(d,index)->{
                        if(index==0) openFile(file);
                        else if(index==1) { exporting=file; saveFile.launch(file.getName()); }
                        else new AlertDialog.Builder(this).setTitle("Delete file?").setMessage(file.getName()).setPositiveButton("Delete",(x,w)->{ if(!file.delete()) toast("Could not delete file"); files(); }).setNegativeButton("Cancel",null).show();
                    }).show();
                },false);
            }
        }
        action("Browse phone files",()->{
            try { browseFiles.launch(new String[]{"*/*"}); }
            catch(Exception e) { toast("No file browser available"); }
        },true);
    }
    private void openFile(File file) {
        try {
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".files",file);
            String extension=android.webkit.MimeTypeMap.getFileExtensionFromUrl(Uri.encode(file.getName()));
            String mime=android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.toLowerCase(Locale.US));
            startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(uri,mime==null?"application/octet-stream":mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
        } catch(Exception e) { toast("No app can open this file. Use Save to export it."); }
    }
    private void settings() {
        begin("settings","Settings & Privacy"); text("EasyFileBridge 1.3.1",16,muted,false);
        text("Appearance",20,ink,true);
        String mode = getPreferences(MODE_PRIVATE).getString("appearance", "system");
        String label = "dark".equals(mode) ? "Dark" : "light".equals(mode) ? "Light" : "System default";
        action("Theme: " + label, () -> {
            if (linking) { toast("Finish connection setup before changing the theme"); return; }
            String[] modes = {"system", "light", "dark"};
            int selected = "dark".equals(mode) ? 2 : "light".equals(mode) ? 1 : 0;
            new AlertDialog.Builder(this).setTitle("Appearance")
                .setSingleChoiceItems(new String[]{"System default", "Light", "Dark"}, selected, (dialog, which) -> {
                    getPreferences(MODE_PRIVATE).edit().putString("appearance", modes[which]).apply(); dialog.dismiss(); recreate();
                }).setNegativeButton("Cancel", null).show();
        }, false);
        gap(12); text("Privacy & connection",20,ink,true);
        action("Terms of Use",()->policy(false),false); action("Privacy Policy",()->policy(true),false);
        action("Wi-Fi settings",()->startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)),false);
        action("Hotspot settings",()->{ try { startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS)); } catch(Exception e) { toast("Open hotspot in your phone Settings"); } },false);
        action("Withdraw agreement",()->new AlertDialog.Builder(this).setTitle("Withdraw agreement?").setMessage("Transfers will stop. Your received files remain on this device until you delete them or uninstall the app.").setPositiveButton("Withdraw",(d,w)->{
            stopFinder(); NearbyLink.close(); stopService(new Intent(this,TransferService.class)); getPreferences(MODE_PRIVATE).edit().remove("agreement").apply(); welcome();
        }).setNegativeButton("Cancel",null).show(),false);
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putString("screen", screen); if (exporting != null) out.putString("exporting", exporting.getAbsolutePath()); super.onSaveInstanceState(out);
    }
    @Override protected void onDestroy() { stopFinder(); super.onDestroy(); }
    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }
    @Override protected void onStart() { super.onStart(); handler.post(ticker); }
    @Override protected void onStop() { handler.removeCallbacks(ticker); super.onStop(); }
}
